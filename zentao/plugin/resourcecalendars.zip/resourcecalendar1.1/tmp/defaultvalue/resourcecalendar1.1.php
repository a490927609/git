<?php
$paramDefaultValue['resourcecalendars']['company']['mode'] = 'wait';
$paramDefaultValue['resourcecalendars']['company']['account'] = '';
$paramDefaultValue['resourcecalendars']['company']['begin'] = '';
$paramDefaultValue['resourcecalendars']['company']['end'] = '';
$paramDefaultValue['resourcecalendars']['person']['mode'] = 'wait';
$paramDefaultValue['resourcecalendars']['person']['begin'] = '';
$paramDefaultValue['resourcecalendars']['person']['end'] = '';
$paramDefaultValue['resourcecalendars']['setload']['isPost'] = 'no';
$paramDefaultValue['resourcecalendars']['ajaxgetusers']['type'] = 'company';
