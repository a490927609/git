<?php
if($config->vision == 'rnd')
{
    $lang->system->menu->resourcecalendars = array('link' => "资源日历|resourcecalendars|company");

    $lang->system->menuOrder[14] = 'resourcecalendars';

    $lang->navGroup->resourcecalendars = 'system';
}
