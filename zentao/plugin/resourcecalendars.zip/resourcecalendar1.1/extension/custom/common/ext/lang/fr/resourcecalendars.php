<?php
if($config->vision == 'rnd')
{
    $lang->system->menu->resourcecalendars = array('link' => "Resource Calendar|resourcecalendars|company");

    $lang->system->menuOrder[14] = 'resourcecalendars';

    $lang->navGroup->resourcecalendars = 'system';
}
