<?php
if($config->vision == 'rnd')
{
    $lang->moduleOrder[] = 'resourcecalendars';

    $lang->resource->resourcecalendars = new stdclass();
    $lang->resource->resourcecalendars->company         = 'company';
    $lang->resource->resourcecalendars->person          = 'person';
    $lang->resource->resourcecalendars->showall         = 'showAll';
    $lang->resource->resourcecalendars->setLoad         = 'setLoad';
    $lang->resource->resourcecalendars->setPredictHours = 'setPredictHours';
}
