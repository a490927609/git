<?php
include dirname(dirname(__FILE__)) . '/resourcecalendars.php';
