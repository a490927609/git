<?php
$config->resourcecalendars = new stdClass();
$config->resourcecalendars->taskHourPredict    = 1;
$config->resourcecalendars->notTaskHourPredict = 1;

$config->resourcecalendars->loadRange['relax']  = '50';
$config->resourcecalendars->loadRange['spare']  = '70';
$config->resourcecalendars->loadRange['normal'] = '90';
$config->resourcecalendars->loadRange['full']   = '100';
$config->resourcecalendars->loadRange['over']   = '120';

$config->resourcecalendars->loadRangeColors = new stdClass();
$config->resourcecalendars->loadRangeColors->relax = new stdClass();
$config->resourcecalendars->loadRangeColors->relax->fore = '#02850C';
$config->resourcecalendars->loadRangeColors->relax->bg   = '#BBEFBF';
$config->resourcecalendars->loadRangeColors->relax->text = '#8CE393';

$config->resourcecalendars->loadRangeColors->spare = new stdClass();
$config->resourcecalendars->loadRangeColors->spare->fore = '#02850C';
$config->resourcecalendars->loadRangeColors->spare->bg   = '#8CE393';
$config->resourcecalendars->loadRangeColors->spare->text = '#8CE393';

$config->resourcecalendars->loadRangeColors->normal = new stdClass();
$config->resourcecalendars->loadRangeColors->normal->fore = '#AF750C';
$config->resourcecalendars->loadRangeColors->normal->bg   = '#FFD281';
$config->resourcecalendars->loadRangeColors->normal->text = '#EDA523';

$config->resourcecalendars->loadRangeColors->full = new stdClass();
$config->resourcecalendars->loadRangeColors->full->fore = '#FFECE2';
$config->resourcecalendars->loadRangeColors->full->bg   = '#FE9863';
$config->resourcecalendars->loadRangeColors->full->text = '#EC5B0F';

$config->resourcecalendars->loadRangeColors->over = new stdClass();
$config->resourcecalendars->loadRangeColors->over->fore = '#C50404';
$config->resourcecalendars->loadRangeColors->over->bg   = '#FF7C7C';
$config->resourcecalendars->loadRangeColors->over->text = '#FF7C7C';

$config->resourcecalendars->loadRangeColors->extreme = new stdClass();
$config->resourcecalendars->loadRangeColors->extreme->fore = '#FBA8A8';
$config->resourcecalendars->loadRangeColors->extreme->bg   = '#D91B1B';
$config->resourcecalendars->loadRangeColors->extreme->text = '#C20000';

$config->resourcecalendars->setload = new stdClass();
$config->resourcecalendars->setload->requiredFields = 'relax,spare,normal,full,over';

global $lang;
$config->resourcecalendars->columns = new stdclass();
$config->resourcecalendars->columns->dept = new stdclass();
$config->resourcecalendars->columns->dept->name  = 'dept';
$config->resourcecalendars->columns->dept->title = $lang->resourcecalendars->dept;
$config->resourcecalendars->columns->dept->width = 70;
$config->resourcecalendars->columns->dept->align = 'left';

$config->resourcecalendars->columns->account = new stdclass();
$config->resourcecalendars->columns->account->name  = 'user';
$config->resourcecalendars->columns->account->title = $lang->resourcecalendars->user;
$config->resourcecalendars->columns->account->width = 80;

$config->resourcecalendars->columns->loadRate = new stdclass();
$config->resourcecalendars->columns->loadRate->name  = 'loadRate';
$config->resourcecalendars->columns->loadRate->title = $lang->resourcecalendars->loadRateCol;
$config->resourcecalendars->columns->loadRate->width = 80;

$config->resourcecalendars->columns->totalEstimatedHours = new stdclass();
$config->resourcecalendars->columns->totalEstimatedHours->name  = 'totalEstimatedHours';
$config->resourcecalendars->columns->totalEstimatedHours->title = $lang->resourcecalendars->totalEstimatedHoursCol;
$config->resourcecalendars->columns->totalEstimatedHours->width = 125;

$config->resourcecalendars->columns->totalConsumeHours = new stdclass();
$config->resourcecalendars->columns->totalConsumeHours->name  = 'totalConsumeHours';
$config->resourcecalendars->columns->totalConsumeHours->title = $lang->resourcecalendars->totalConsumeHoursCol;
$config->resourcecalendars->columns->totalConsumeHours->width = 110;

$config->resourcecalendars->columns->waitCount = new stdclass();
$config->resourcecalendars->columns->waitCount->name  = 'waitCount';
$config->resourcecalendars->columns->waitCount->title = $lang->resourcecalendars->waitCountCol;
$config->resourcecalendars->columns->waitCount->width = 100;

$config->resourcecalendars->columns->doneCount = new stdclass();
$config->resourcecalendars->columns->doneCount->name  = 'doneCount';
$config->resourcecalendars->columns->doneCount->title = $lang->resourcecalendars->doneCountCol;
$config->resourcecalendars->columns->doneCount->width = 100;

$config->resourcecalendars->columns->taskCount = new stdclass();
$config->resourcecalendars->columns->taskCount->name  = 'taskCount';
$config->resourcecalendars->columns->taskCount->title = $lang->resourcecalendars->taskCountCol;
$config->resourcecalendars->columns->taskCount->width = 80;

$config->resourcecalendars->columns->project = new stdclass();
$config->resourcecalendars->columns->project->name  = 'project';
$config->resourcecalendars->columns->project->title = '';

$config->resourcecalendars->columns->estimatedHours = new stdclass();
$config->resourcecalendars->columns->estimatedHours->name  = 'estimatedHours';
$config->resourcecalendars->columns->estimatedHours->title = $lang->resourcecalendars->estimatedHoursCol;

$config->resourcecalendars->columns->consumeHours = new stdclass();
$config->resourcecalendars->columns->consumeHours->name  = 'consumeHours';
$config->resourcecalendars->columns->consumeHours->title = $lang->resourcecalendars->consumeHoursCol;
$config->resourcecalendars->columns->consumeHours->width = 80;

$config->resourcecalendars->columns->deadline = new stdclass();
$config->resourcecalendars->columns->deadline->name  = 'deadline';
$config->resourcecalendars->columns->deadline->title = $lang->resourcecalendars->deadlineCol;
$config->resourcecalendars->columns->deadline->width = 90;
$config->resourcecalendars->columns->deadline->align = 'left';

$config->resourcecalendars->finishStatusList['todo']     = 'done';
$config->resourcecalendars->finishStatusList['bug']      = 'resolved';
$config->resourcecalendars->finishStatusList['feedback'] = 'replied';
$config->resourcecalendars->finishStatusList['ticket']   = 'done';
$config->resourcecalendars->finishStatusList['issue']    = 'resolved';
