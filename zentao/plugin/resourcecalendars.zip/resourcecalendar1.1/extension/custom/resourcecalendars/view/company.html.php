<?php include $app->moduleRoot . 'common/view/header.html.php';?>
<?php js::import($jsRoot . 'zui/resourcecalendar/min.cjs'); ?>
<?php css::import($jsRoot . 'zui/resourcecalendar/min.css'); ?>

<?php js::set('options',            $calendarData);?>
<?php js::set('today',              $today);?>
<?php js::set('mode',               $mode);?>
<?php js::set('method',             $app->rawMethod);?>
<?php js::set('userAccount',        $account);?>
<?php js::set('userNotEmpty',       sprintf($lang->error->notempty, $lang->resourcecalendars->user));?>
<?php js::set('paramList',          $paramList);?>
<?php js::set('isSimulate',         $isSimulate);?>
<?php js::set('workHours',          $defaultWorkhours);?>
<?php js::set('taskHourPredict',    $config->resourcecalendars->taskHourPredict);?>
<?php js::set('notTaskHourPredict', $config->resourcecalendars->notTaskHourPredict);?>
<style>
<?php foreach($config->resourcecalendars->loadRangeColors as $name => $color) echo ".loadType-$name .label-dot {background-color: $color->bg}";?>
<?php if(file_exists($app->wwwRoot . 'theme/default/images/severity/severity-sprite.png')):?>
.label-severity {background: url('/theme/default/images/severity/severity-sprite.png') no-repeat; border: none; height: 26px; line-height: 32px;  background-position: 5px -131px; color: #9EA3B0; min-width: 24px; max-width: 24px; background-size: 80%;}
.label-severity:after {top: 6px; left: 3px;}
.label-severity[data-severity="1"] {color: #FB2B2B; background-position: 5px 1px;}
.label-severity[data-severity="2"] {color: #FF8058; background-position: 5px -32.5px;}
.label-severity[data-severity="3"] {color: #FAAE1A; background-position: 5px -66px;}
.label-severity[data-severity="4"] {color: #B89664; background-position: 5px -98px;}
<?php else:?>
.label-severity:before {top: -2px; font-size: 18px;}
.label-severity:after {top: 4px; left: -3px;}
<?php endif;?>
<?php if(common::checkNotCN()):?>
.picker-actions .btn+.btn {margin-left: 0px;}
<?php endif;?>
</style>
<div id="mainMenu" class="clearfix">
  <div class="btn-toolbar main-content">
    <form id='searchForm' method='post' class="not-watch">
      <?php if(common::hasPriv('resourcecalendars', 'showAll')):?>
      <div class="input-control space deptBox">
        <span class="form-name"><strong><?php echo $lang->resourcecalendars->dept;?></strong></span>
        <?php echo html::select('depts[]', $deptList, $depts, 'class="form-control picker-select" multiple');?>
      </div>
      <?php endif;?>
      <div class="input-control space roleBox">
        <span class="form-name"><strong><?php echo $lang->resourcecalendars->role;?></strong></span>
        <?php echo html::select('roles[]', array('empty' => '/') + $lang->user->roleList, $roles, 'class="form-control picker-select" multiple');?>
      </div>
      <?php if(common::hasPriv('resourcecalendars', 'showAll')):?>
      <div class="input-control space projectBox">
        <span class="form-name"><strong><?php echo $lang->resourcecalendars->projectTeam;?></strong></span>
        <?php echo html::select('project', $projectList, $project, 'class="form-control chosen" data-width="120px" data-max_drop_width="200px"');?>
      </div>
      <?php endif;?>
      <div class="input-control space userBox">
        <span class="form-name"><strong><?php echo $lang->resourcecalendars->user;?></strong></span>
        <?php if($app->rawMethod == 'company'):?>
        <?php echo html::select('users[]', $userList, $users, 'class="form-control picker-select" multiple');?>
        <?php else:?>
        <?php echo html::select('users[]', $userList, $users, 'class="form-control chosen" data-width="120px"');?>
        <?php endif;?>
      </div>
      <div class="input-control space">
        <span class="form-name"><strong><?php echo $lang->resourcecalendars->date;?></strong></span>
        <div class='input-group has-icon-right'>
           <?php echo html::input('begin', $begin, 'class="form-control form-date" readonly');?>
           <label for='begin' class='input-control-icon-right'><i class='icon icon-calendar'></i></label>
        </div>
        <span class="form-name"><strong><?php echo $lang->resourcecalendars->to;?></strong></span>
        <div class='input-group has-icon-right'>
           <?php echo html::input('end', $end, 'class="form-control form-date" readonly');?>
           <label for='end' class='input-control-icon-right'><i class='icon icon-calendar'></i></label>
        </div>
      </div>
      <?php echo html::commonButton($lang->resourcecalendars->search, 'id="searchBtn"', 'btn btn-primary pull-right');?>
    </form>
  </div>
  <div class="second-toolbar">
    <div class="btn-toolbar pull-left">
      <?php if(!$isSimulate):?>
      <?php echo html::a('#', "<span class='text'>{$lang->resourcecalendars->wait}</span>", '', "data-value='wait' class='btn btn-link switchTab" . ($mode == 'wait' ? " btn-active-text'" : "'"));?>
      <?php echo html::a('#', "<span class='text'>{$lang->resourcecalendars->done}</span>", '', "data-value='done' class='btn btn-link switchTab" . ($mode == 'done' ? " btn-active-text'" : "'"));?>
      <div class="btn-group dropdown searchTypeBox">
        <button class="btn btn-link" data-toggle="dropdown"><span class="text"><?php echo zget($lang->resourcecalendars->searchType, $searchType);?></span> <span class="caret"></span></button>
        <ul class="dropdown-menu">
          <?php
          foreach($lang->resourcecalendars->searchType as $type => $searchTypeName)
          {
              $active = $type == $searchType ? 'active' : '';
              echo "<li class='$active'>" . html::a('#', $searchTypeName, '', "class='searchType' data-type=$type") . "</li>";
          }
          ?>
        </ul>
      </div>
      <?php else:?>
      <div class='pull-left work-hours'>
      <div class='pull-left'><?php echo $lang->resourcecalendars->defaultWorkhours;?></div>
        <div class='pull-left input-group has-icon-right'>
          <?php echo html::input('workHoursPerDay', $defaultWorkhours, "class='form-control loadrange-input'");?>
          <label for='workHoursPerDay' class='input-control-icon-right'>h</label>
        </div>
      </div>
      <?php endif;?>
      <?php echo html::checkbox('showHoliday', array('1' => $lang->resourcecalendars->showHoliday), '', 'title="' . ($this->config->edition == 'open' ? $lang->resourcecalendars->holidayTipForOpen : $lang->resourcecalendars->holidayTip) . '"');?>
      <?php if(!$isSimulate):?>
      <div class='totalAvailableHours pull-left' data-toggle="popover"><?php echo $lang->resourcecalendars->totalAvailableHours . " <span class='gray-14'>{$totalAvailableHours}</span> h";?>
        <div class='popover popover-hours'>
          <table>
            <tr>
              <td><?php echo $lang->resourcecalendars->totalWorkDays;?><td>
              <td><?php echo $workDays . $lang->resourcecalendars->day;?><td>
            </tr>
            <tr>
              <td><?php echo $lang->resourcecalendars->defaultWorkhours;?><td>
              <td><?php echo $defaultWorkhours . 'h';?><td>
            </tr>
            <tr>
              <td><?php echo $lang->resourcecalendars->totalAvailableHours;?><td>
              <td><?php echo $totalAvailableHours . 'h';?><td>
            </tr>
          </table>
        </div>
      </div>
      <?php endif;?>
      <div class='loadType pull-left' data-toggle="popover">
        <ul class='load-type'>
        <?php foreach($lang->resourcecalendars->loadType as $loadType => $loadName):?>
          <?php $class = 'loadType-' . $loadType;?>
          <li class="<?php echo $class;?> pull-left">
            <span class="label label-dot"></span><?php echo $loadName;?>
          </li>
        <?php endforeach;?>
        </ul>
        <div class="popover bottom load-popover">
          <div class='text-center'>
            <h4><?php echo $lang->resourcecalendars->loadRangeTip;?></h4>
          </div>
          <table class='table table-borderless loadRange-table'>
            <?php $prevType = '';?>
            <?php foreach($lang->resourcecalendars->loadType as $loadType => $loadName):?>
            <tr class='<?php echo "loadType-$loadType";?>'>
              <td><span class="label label-dot"></span></td>
              <td class='text-right'><?php echo zget($config->resourcecalendars->loadRange, $prevType, 0) . ' ≤';?></td>
              <td><?php echo $loadName;?></td>
              <td class='text-left'><?php echo '< ' . zget($config->resourcecalendars->loadRange, $loadType, '<i class="icon icon-infinite"></i>');?></td>
            </tr>
            <?php $prevType = $loadType;?>
            <?php endforeach;?>
          </table>
        </div>
      </div>
    </div>
    <div class="btn-toolbar pull-right">
      <?php if(!$isSimulate and (common::hasPriv('resourcecalendars', 'setLoad') or common::hasPriv('custom', 'set') or ($config->edition != 'open' and common::hasPriv('holiday', 'browse')) or common::hasPriv('resourcecalendars', 'setPredictHours'))):?>
      <div class='btn-group menu-actions'>
        <?php echo html::a('javascript:;', "<i class='icon icon-cog-outline muted'></i> " . $lang->settings, '', "data-toggle='dropdown' class='btn btn-link'")?>
        <ul class='dropdown-menu pull-right'>
          <?php if(common::hasPriv('custom', 'set')) echo '<li>' . html::a(helper::createLink('resourcecalendars', 'setHours', '', '', true), $lang->resourcecalendars->setHours, '', "class='btn btn-link iframe' title='{$lang->resourcecalendars->setHours}' data-width='500px'") . '</li>';?>
          <?php if($config->edition != 'open' and common::hasPriv('holiday', 'browse')) echo '<li>' . html::a(helper::createLink('holiday', 'browse'), $lang->resourcecalendars->setHoliday, '', "class='btn btn-link' title='{$lang->resourcecalendars->setHoliday}' data-app='oa'") . '</li>';?>
          <?php if(common::hasPriv('resourcecalendars', 'setLoad')) echo '<li>' . html::a(helper::createLink('resourcecalendars', 'setLoad', '', '', true), $lang->resourcecalendars->setLoad, '', "class='btn btn-link iframe' title='{$lang->resourcecalendars->setLoad}' data-width='600px'") . '</li>';?>
          <?php $width = common::checkNotCN() ? '900px' : '820px';?>
          <?php if(common::hasPriv('resourcecalendars', 'setPredictHours')) echo '<li>' . html::a(helper::createLink('resourcecalendars', 'setPredictHours', '', '', true), $lang->resourcecalendars->setPredictHours, '', "class='btn btn-link iframe' title='{$lang->resourcecalendars->setPredictHours}' data-width='$width'") . '</li>';?>
        </ul>
      </div>
      <?php if($app->rawMethod == 'person') echo '<div class="divider"></div>';?>
      <?php endif;?>
      <?php if($app->rawMethod == 'person') echo html::a('javascript:;', "<i class='icon-back muted'></i> " . $lang->goback, '', "class='btn btn-link goback' id='gobackBtn'")?>
      <?php
      if($app->rawMethod == 'company' and $mode == 'wait')
      {
          if($isSimulate)
          {
              echo html::a(helper::createLink('resourcecalendars', 'company', "mode=wait"), "<span class='text-primary'>{$lang->resourcecalendars->simulatedExit}</span>", '', "class='btn text-primary'");
          }
          else
          {
              echo html::a(helper::createLink('resourcecalendars', 'company', "mode=simulate&account=''&begin=$begin&end=$end"), "<span class='text-primary'>{$lang->resourcecalendars->simulatedLoad}</span>", '', "class='btn text-primary' title='{$lang->resourcecalendars->imitateTip}'");
          }
      }
      ?>
    </div>
  </div>
</div>
<div id='resourcecalendars'></div>
<?php include $app->moduleRoot . 'common/view/footer.html.php';?>
