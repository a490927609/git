<?php include $app->moduleRoot . 'common/view/header.html.php';?>
<?php if(common::checkNotCN()):?>
<style>
.table > tbody .c-taskHourPredict > th {width: 245px;}
.table > tbody td.setHoursBox > .predictHoursTitle {width: 140px;}
</style>
<?php endif?>
<div id='mainContent' class='main-content'>
  <div class='main-header'>
    <h2><?php echo $lang->resourcecalendars->setPredictHours;?></h2>
  </div>
  <form class="load-indicator main-form" method='post' target='hiddenwin'>
    <table class='table table-form'>
      <tr class='c-taskHourPredict'>
        <th><?php echo $lang->resourcecalendars->taskHourPredict;?></th>
        <td class='setHoursTd'><?php echo html::radio('taskHourPredict', $lang->resourcecalendars->setHoursList, $taskHourPredict);?></td>
        <td></td>
      </tr>
      <tr class='c-notTaskHourPredict'>
        <th><?php echo $lang->resourcecalendars->notTaskHourPredict;?></th>
        <td class='setHoursTd'><?php echo html::radio('notTaskHourPredict', $lang->resourcecalendars->setHoursList, $notTaskHourPredict);?></td>
        <?php $hidden   = $notTaskHourPredict ? '' : 'hidden';?>
        <?php $disabled = $notTaskHourPredict ? '' : 'disabled';?>
        <td class="<?php echo $hidden?> setHoursBox">
          <div class='predictHoursTitle'><?php echo $lang->resourcecalendars->predictHoursTitle;?></div>
          <div class='input-group has-icon-right predictHoursBox'>
            <?php echo html::input('predictHours', $predictHours, "class='form-control' required $disabled");?>
            <label class='input-control-icon-right'>h</label>
          </div>
        </td>
      </tr>
      <tr>
       <?php $tip = $this->config->edition . 'SetpredicthoursTip'?>
       <?php
       if(!$config->URAndSR)
       {
           $prefix = common::checkNotCN() ? ', ' : '、';
           $lang->resourcecalendars->$tip = str_replace($prefix . $this->lang->URCommon, '', $lang->resourcecalendars->$tip);
       }
       ?>
        <td colspan='3' class='tipBox'><?php echo $lang->resourcecalendars->$tip;?></td>
      </tr>
      <tr>
        <td colspan='3' class='text-center'><?php echo html::submitButton();?></td>
      </tr>
    </table>
  </form>
</div>
<?php include $app->moduleRoot . 'common/view/footer.html.php';?>
