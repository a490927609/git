$(function()
{
    $('#defaultWorkhours').on('keyup', function(event)
    {
        var defaultWorkhours = $(this).val();

        defaultWorkhours = defaultWorkhours.match(/(^\d+\.\d*)|(^\d+)/g) || '';
        $(this).val(defaultWorkhours);
    })
});
