$(function()
{
    $('.loadRange-table input').on('keyup', function()
    {
        var $loadRangeType = $(this);
        var loadRange      = $loadRangeType.val().replaceAll('.', '').replaceAll('"', '').replaceAll('-', '');

        loadRange = loadRange ? parseInt(loadRange) : '';
        if(isNaN(loadRange)) loadRange = '';
        $loadRangeType.val(loadRange);
        if(loadRange > 999)
        {
            $loadRangeType.val(999);
        }
        else if(loadRange < 1)
        {
            $loadRangeType.val('');
        }

        var type = $loadRangeType.data('type');
        $('.type-' + type).val($loadRangeType.val());
    });

    parent.$('#triggerModal .modal-content .modal-header .close').click(function()
    {
        if(isPost == 'yes') parent.location.reload();
    });


});
