$(function()
{
    $('input[name="notTaskHourPredict"]').click(function()
    {
        var isOpen = $(this).val() == 1 ? true : false;
        if(isOpen)
        {
            $('#predictHours').removeAttr('disabled');
            $('.setHoursBox').removeClass('hidden');
        }
        else
        {
            console.log(111111);
            $('#predictHours').attr('disabled', 'disabled');
            $('.setHoursBox').addClass('hidden');
        }
    });

    $('#predictHours').on('keyup', function(event)
    {
        var predictHours = $(this).val();

        predictHours = predictHours.match(/(^\d{1,3}\.\d{0,1})|(^\d{1,3})/g) || '';
        $(this).val(predictHours);
    })
})
