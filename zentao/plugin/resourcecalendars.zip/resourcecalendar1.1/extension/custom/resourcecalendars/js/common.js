$(function()
{
    $('#mainMenu .pull-left > .switchTab').click(function()
    {
        var mode        = $(this).attr('data-value');
        var param       = method == 'company' ? 'mode=' + mode : 'account=' + userAccount + '&mode=' + mode;
        var link        = createLink('resourcecalendars', method, param);
        var $searchForm = $('#searchForm');

        $('#begin, #end').attr('disabled', true);
        $searchForm.attr('action', link);
        $searchForm.submit();
    });

    $('#workHoursPerDay').on('keyup', function(e)
    {
        var hours = $('#workHoursPerDay').val().match(/(^(\d){1,2}\.\d?)|(^\d{1,2})/g) || '';
        if(hours) hours = hours[0];
        if(hours === '00' || hours === '00.00')
        {
            hours = 0;
        }
        else if(hours > 24)
        {
            hours = 24;
        }
        else if(hours < 0)
        {
            hours = 1;
        }
        $('#workHoursPerDay').val(hours);

        if(e.keyCode == 13)
        {
            if(!hours || hours == '0')
            {
                hours = workHours;
                $('#workHoursPerDay').val(hours);
            }
            options.workHoursPerDay = parseFloat(hours);
            initView();
        }
    });

    $('#workHoursPerDay').on('change', function()
    {
        var hours = parseFloat($(this).val());
        if(!hours || hours == '0')
        {
            hours = workHours;
            $('#workHoursPerDay').val(hours);
        }

        options.workHoursPerDay = hours;
        initView();
    });

    /**
     * Iinit resource sheet.
     *
     * @access public
     * @return void
     */
    function initView()
    {
        var searchType  = $.cookie('searchType');
        var showHoliday = eval($.cookie('showHoliday'));

        $('#showHoliday1').attr('checked', showHoliday);
        if(searchType && searchType != 'day') $('#showHoliday1').attr('disabled', true);
        if(isSimulate) searchType = 'day';

        options.height             = $(window).height() - $('#header').height() - $('#mainMenu').height() - 30;
        options.includeHoliday     = showHoliday;
        options.viewType           = searchType ? searchType : 'day';
        options.simulate           = isSimulate;
        options.taskHourPredict    = taskHourPredict == 1 ? true : false;
        options.notTaskHourPredict = notTaskHourPredict == 1 ? true : false;
        options.collapseAllGroups  = true;

        var ressheet = $('#resourcecalendars').data('zui.ressheet');
        if(ressheet)
        {
            ressheet.render(options);
        }
        else
        {
            $('#resourcecalendars').ressheet(options);
        }
    }

    /**
     * Update user list.
     *
     * @access public
     * @return void
     */
    function setUserSelect()
    {
        var depts   = $('#depts').val();
        var roles   = $('#roles').val();
        var users   = $('#users').val();
        var project = $('#project').val();

        $.post(
            createLink('resourcecalendars', 'ajaxGetUsers', 'type=' + method),
            {
                depts:   depts,
                roles:   roles,
                project: project,
                users: users
            },
            function(userData)
            {
                $('#users').replaceWith(userData);
                $('#users').next().remove();
                if($('#users').hasClass('chosen'))
                {
                    $('#users').chosen();
                }
                else
                {
                    $('#users').picker();
                }
            }
        );
    }

    if(typeof options != 'undefined')
    {
        initView();
        if(mode == 'wait')
        {
            $('#begin').datetimepicker('setStartDate', today);
            $('#end').datetimepicker('setStartDate', today);
        }
        else
        {
            $('#begin').datetimepicker('setEndDate', today);
            $('#end').datetimepicker('setEndDate', today);
        }

        $('#searchForm .date-group .input-group-addon').on('click', function()
        {
            $(this).prev().datetimepicker('show');
        });

        $('#begin').on('change', function()
        {
            if($('#begin').val() > $('#end').val()) $('#begin').val($('#end').val());

            $('#end').datetimepicker('setStartDate', $(this).val());
        });

        $('#end').on('change', function()
        {
            if($('#begin').val() > $('#end').val()) $('#end').val($('#begin').val());

            $('#begin').datetimepicker('setEndDate', $(this).val());
        });

        $('.searchTypeBox .searchType').on('click', function()
        {
            var searchType = $(this).attr('data-type');
            $.cookie('searchType', searchType, {expires:config.cookieLife, path:config.webRoot});
            $('.searchTypeBox .btn-link > .text').text($(this).text());
            $(this).closest('ul').find('li').removeClass('active');
            $(this).closest('li').addClass('active');

            if(searchType != 'day') {
                $('#showHoliday1').attr('disabled', true);
                $('#showHoliday1').attr('checked', true);
                $.cookie('showHoliday', 1, {expires:config.cookieLife, path:config.webRoot});
            }
            else
            {
                $('#showHoliday1').attr('disabled', false);
            }

            initView();
        });

        $('#showHoliday1').on('click', function()
        {
            var showHoliday = $('#showHoliday1').is(':checked');
            $.cookie('showHoliday', showHoliday, {expires:config.cookieLife, path:config.webRoot});
            initView();
        });

        $('#depts, #roles, #project').on('change', function()
        {
            setUserSelect();
        });

        var popoverOptions = {
            container: 'body',
            content: $('.load-popover').html(),
            html: true,
            placement: 'bottom',
            template: '<div class="popover"><div class="popover-content"></div></div>',
            trigger: 'hover'
        };

        $('.loadType').popover(popoverOptions);

        var tipOptions = {
            container: 'body',
            content: $('.popover-hours').html(),
            html: true,
            placement: 'bottom',
            template: '<div class="popover"><div class="popover-content"></div></div>',
            trigger: 'hover'
        };
        $('.totalAvailableHours').popover(tipOptions);

        $('#searchBtn,#gobackBtn').on('click', function()
        {
            if(method == 'person')
            {
                if($(this).hasClass('goback'))
                {
                    var url = createLink('resourcecalendars', 'company', 'mode=' + mode);
                }
                else
                {
                    var account = $('#users').val();
                    if(!account)
                    {
                        bootbox.alert(userNotEmpty);
                        return false;
                    }
                    var url = createLink('resourcecalendars', 'person', 'account=' + account + '&mode=' + mode);
                }

                $("#searchForm").attr('action', url);
            }

            $("#searchForm").submit();
        });

        window.onresize = initView;
    }
})
