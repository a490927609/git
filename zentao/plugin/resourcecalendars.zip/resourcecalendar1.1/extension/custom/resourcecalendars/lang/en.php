<?php
/* Field. */
$lang->resourcecalendars->common                 = 'Resource Calendar';
$lang->resourcecalendars->dept                   = 'Dept';
$lang->resourcecalendars->user                   = 'User';
$lang->resourcecalendars->role                   = 'Role';
$lang->resourcecalendars->projectTeam            = 'Project Team';
$lang->resourcecalendars->date                   = 'Date';
$lang->resourcecalendars->today                  = 'Today';
$lang->resourcecalendars->to                     = 'To';
$lang->resourcecalendars->search                 = 'Search';
$lang->resourcecalendars->consumeHoursPerDay     = 'Average Daily Hours Spent';
$lang->resourcecalendars->loadRate               = 'Load Rate';
$lang->resourcecalendars->loadRateCol            = 'Load Rate(%)';
$lang->resourcecalendars->totalLoadRate          = 'Total Load Rate';
$lang->resourcecalendars->leave                  = 'Leave';
$lang->resourcecalendars->waitItem               = 'Wait Item';
$lang->resourcecalendars->doneItem               = 'Done Item';
$lang->resourcecalendars->waitCountCol           = 'Wait';
$lang->resourcecalendars->doneCountCol           = 'Done';
$lang->resourcecalendars->totalConsumeHoursCol   = 'Total Consumed(h)';
$lang->resourcecalendars->totalEstimatedHours    = 'Unfinished Work';
$lang->resourcecalendars->totalEstimatedHoursCol = 'Unfinished Work(h)';
$lang->resourcecalendars->consumeHoursCol        = 'Consumed(h)';
$lang->resourcecalendars->estimatedHoursCol      = 'Estimate(h)';
$lang->resourcecalendars->estimateHoursPerDay    = 'Average Daily Hours Forecast';
$lang->resourcecalendars->loadRateCol            = 'Load Rate(%)';
$lang->resourcecalendars->taskCountCol           = 'Task Count';
$lang->resourcecalendars->projectCol             = 'Project';
$lang->resourcecalendars->deadlineCol            = 'Deadline';
$lang->resourcecalendars->company                = 'Company Resource Calendar';
$lang->resourcecalendars->person                 = 'Person Resource Calendar';
$lang->resourcecalendars->showAll                = 'View Everyone Resource Calendar';
$lang->resourcecalendars->setting                = 'Resource Calendar Setting';
$lang->resourcecalendars->wait                   = 'Wait';
$lang->resourcecalendars->done                   = 'Done';
$lang->resourcecalendars->showHoliday            = 'Include Holiday';
$lang->resourcecalendars->setHours               = 'Setting Hours';
$lang->resourcecalendars->setHoliday             = 'Setting Holiday';
$lang->resourcecalendars->setLoad                = 'Setting Load';
$lang->resourcecalendars->setLoadAB              = 'Load Setting';
$lang->resourcecalendars->setPredictHours        = 'Setting Estimation for Each Item';
$lang->resourcecalendars->future                 = 'TBD';
$lang->resourcecalendars->longTime               = 'Long-Term';
$lang->resourcecalendars->monthRange             = '{0} ~ {1}';
$lang->resourcecalendars->countUnit              = '{0} Times';
$lang->resourcecalendars->dayCount               = '{0}D';
$lang->resourcecalendars->fullDate               = 'MM/dd/yyyy';
$lang->resourcecalendars->yearDate               = 'yyyy';
$lang->resourcecalendars->monthDate              = 'MM/dd';
$lang->resourcecalendars->waitSummary            = 'Total items: <strong>%s</strong>, Tasks: <strong>%s</strong>, Unfinished: <strong>%s</strong> h.';
$lang->resourcecalendars->doneSummary            = 'Total items: <strong>%s</strong>, Tasks: <strong>%s</strong>, Consumed: <strong>%s</strong> h.';
$lang->resourcecalendars->simulatedLoad          = 'Load Simulation';
$lang->resourcecalendars->simulatedExit          = 'Quit Simulated';
$lang->resourcecalendars->taskHourPredict        = 'System forecast for task-based items';
$lang->resourcecalendars->notTaskHourPredict     = 'Forecast for un-task-based items';
$lang->resourcecalendars->predictHoursTitle      = 'Forecast for each item';
$lang->resourcecalendars->totalAvailableHours    = 'Total available hours';
$lang->resourcecalendars->day                    = 'Day';
$lang->resourcecalendars->totalWorkDays          = 'Total workdays';
$lang->resourcecalendars->defaultWorkhours       = 'Daily available hours';
$lang->resourcecalendars->batchAdjust            = 'Overall';
$lang->resourcecalendars->dynamicType            = 'Dynamic Class';
$lang->resourcecalendars->actionTimes            = 'Actions in Total';
$lang->resourcecalendars->clear                  = 'Clear';
$lang->resourcecalendars->workHours              = 'Manual Forecast Hours';
$lang->resourcecalendars->predictHours           = 'System Forecast Hours';
$lang->resourcecalendars->totalHours             = 'Total Forecast Remaining Hours';
$lang->resourcecalendars->workHoursPerDay        = 'Average uncompleted workload';
$lang->resourcecalendars->simulateConfirmTip     = 'The current drag including {0} days of holidays with an expected';
$lang->resourcecalendars->makeupOverTimeTip      = 'This value exceeds the number of holiday days';
$lang->resourcecalendars->increaseWorkDays       = 'Add {0} working days';
$lang->resourcecalendars->decreaseWorkDays       = 'Reduce {0} working days';
$lang->resourcecalendars->deleted                = 'Deleted';

/* Tip. */
$lang->resourcecalendars->rangeTip                = 'Range';
$lang->resourcecalendars->loadRangeTip            = 'Color and Load Rate Range';
$lang->resourcecalendars->imitateTip              = 'You can preview the duration of to-do and the workload ratio with this feature.';
$lang->resourcecalendars->holidayTip              = 'The holiday data depending on the settings in Admin-Custom-Task-Effort (1 days off or 2 days off in a week) and holiday settings in OA module.';
$lang->resourcecalendars->holidayTipForOpen       = 'The holiday data comes from the settings in Admin-Custom-Task-Effort (1 days off or 2 days off in a week).';
$lang->resourcecalendars->userDeletedTip          = 'The user has been deleted.';
$lang->resourcecalendars->userNotExistTip         = 'The user does not exist.';
$lang->resourcecalendars->waitTaskCountTip        = 'The sum of the number of to-be-started task and in-progress task assigned to the current user.';
$lang->resourcecalendars->doneTaskCountTip        = 'The number of task for which the current user has recorded effort.';
$lang->resourcecalendars->totalConsumeTip         = 'The sum of the effort log recorded by employees.';
$lang->resourcecalendars->waitLoadRateTip         = 'Total estimated work hours / (available work hours per day * working days)';
$lang->resourcecalendars->doneLoadRateTip         = 'Total work hours spent / (available work hours per day * working days)';
$lang->resourcecalendars->openWaitCountTip        = 'The sum of the number of task, todo, ' . $lang->SRCommon . ', ' . $lang->URCommon . ', bug, case and test task assigned to the current user.';
$lang->resourcecalendars->bizWaitCountTip         = 'The sum of the number of task, todo, ' . $lang->SRCommon . ', ' . $lang->URCommon . ', bug, case, test task, feedback, and ticket assigned to the current user.';
$lang->resourcecalendars->maxWaitCountTip         = 'The sum of the number of task, todo, ' . $lang->SRCommon . ', ' . $lang->URCommon . ', bug, case, test task, feedback, ticket, issue, risk, review, and QA assigned to the current user.';
$lang->resourcecalendars->openDoneCountTip        = 'The number of items that the current user has recorded logs effort in tasks.';
$lang->resourcecalendars->bizDoneCountTip         = 'The number of items that the current user has recorded logs effort in task, todo, ' . $lang->SRCommon . ', ' . $lang->URCommon . ', bug, plan, feedback, and ticket.';
$lang->resourcecalendars->maxDoneCountTip         = 'The number of items that the current user has recorded logs effort in task, todo, ' . $lang->SRCommon . ', ' . $lang->URCommon . ', bug, plan, feedback, ticket, issue, risk, and review.';
$lang->resourcecalendars->batchAdjustTip          = 'Tip: Drag the round slider to preview the duration change, and the daily working hours are shown in the slider.';
$lang->resourcecalendars->waitWorkHoursTip        = 'It means the sum of the forecast working hours for all todo items for the current user over <strong>{0}</strong> business days.<br>Calculation formula: Unfinished work = Manual forecast of working hours for tasks + System forecast of working hours for tasks + Forecast of working hours for other todo items';
$lang->resourcecalendars->waitTaskWorkHoursTip    = 'It means the sum of the forecast working hours for all todo items for the current user over <strong>{0}</strong> business days.<br>Calculation formula: Unfinished work = Manual forecast of working hours for tasks + System forecast of working hours for tasks';
$lang->resourcecalendars->waitNotTaskWorkHoursTip = 'It means the sum of the forecast working hours for all todo items for the current user over <strong>{0}</strong> business days.<br>Calculation formula: Unfinished work = Manual forecast of working hours for tasks + Forecast of working hours for other todo items';

$lang->resourcecalendars->openSetpredicthoursTip = <<<EOF
<div class='tip-title'><p>Note:<p></div>
<div class='tip-content'>
  <p>1.With it enabled, the forecast hours will be always shown on resource calendar.</p>
  <p>2.Forecast for un-task-based items: It will be calculated according to individual's efficiency.</p>
  <p>3.Un-task-based items including {$lang->SRCommon}, {$lang->URCommon}, bug, todo, use case, test request and plan.</p>
  <p>4.The default value here is the average value calculated from system logs. You can make your own changes.</p>
  <p>5.There are inaccuracies in the default values.</p>
  <p>6.When you make your own changes, be careful with other parallel items and leave more necessary buffer time.</p>
</div>
EOF;

$lang->resourcecalendars->bizSetpredicthoursTip = <<<EOF
<div class='tip-title'><p>Note:<p></div>
<div class='tip-content'>
  <p>1.With it enabled, the forecast hours will be always shown on resource calendar.</p>
  <p>2.Forecast for un-task-based items: It will be calculated according to individual's efficiency.</p>
  <p>3.Un-task-based items including {$lang->SRCommon}, {$lang->URCommon}, bug, todo, use case, test request, plan, feedback and ticket.</p>
  <p>4.The default value here is the average value calculated from system logs. You can make your own changes.</p>
  <p>5.There are inaccuracies in the default values.</p>
  <p>6.When you make your own changes, be careful with other parallel items and leave more necessary buffer time.</p>
</div>
EOF;

$lang->resourcecalendars->maxSetpredicthoursTip = <<<EOF
<div class='tip-title'><p>Note:<p></div>
<div class='tip-content'>
  <p>1.With it enabled, the forecast hours will be always shown on resource calendar.</p>
  <p>2.Forecast for un-task-based items: It will be calculated according to individual's efficiency.</p>
  <p>3.Un-task-based items including {$lang->SRCommon}, {$lang->URCommon}, bug, todo, use case, test request, plan, feedback, ticket, risk, issue, review, and QA.</p>
  <p>4.The default value here is the average value calculated from system logs. You can make your own changes.</p>
  <p>5.There are inaccuracies in the default values.</p>
  <p>6.When you make your own changes, be careful with other parallel items and leave more necessary buffer time.</p>
</div>
EOF;

$lang->resourcecalendars->monthNames = array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');

$lang->resourcecalendars->weekDayNames[0] = 'Mon';
$lang->resourcecalendars->weekDayNames[1] = 'Tue';
$lang->resourcecalendars->weekDayNames[2] = 'Wed';
$lang->resourcecalendars->weekDayNames[3] = 'Thu';
$lang->resourcecalendars->weekDayNames[4] = 'Fri';
$lang->resourcecalendars->weekDayNames[5] = 'Sat';
$lang->resourcecalendars->weekDayNames[6] = 'Sun';

$lang->resourcecalendars->loadType['relax']   = 'Relaxed';
$lang->resourcecalendars->loadType['spare']   = 'Spare';
$lang->resourcecalendars->loadType['normal']  = 'Normal';
$lang->resourcecalendars->loadType['full']    = 'Full';
$lang->resourcecalendars->loadType['over']    = 'Over';
$lang->resourcecalendars->loadType['extreme'] = 'Extreme';

$lang->resourcecalendars->searchType['day']   = 'Day';
$lang->resourcecalendars->searchType['week']  = 'Week';
$lang->resourcecalendars->searchType['month'] = 'Month';

$lang->resourcecalendars->dataTypeList['task']        = 'Task';
$lang->resourcecalendars->dataTypeList['todo']        = 'Todo';
$lang->resourcecalendars->dataTypeList['bug']         = 'Bug';
$lang->resourcecalendars->dataTypeList['story']       = $lang->SRCommon;
$lang->resourcecalendars->dataTypeList['requirement'] = $lang->URCommon;
$lang->resourcecalendars->dataTypeList['testcase']    = 'Case';
$lang->resourcecalendars->dataTypeList['testtask']    = 'Test Task';
$lang->resourcecalendars->dataTypeList['feedback']    = 'Feedback';
$lang->resourcecalendars->dataTypeList['ticket']      = 'Ticket';
$lang->resourcecalendars->dataTypeList['risk']        = 'Risk';
$lang->resourcecalendars->dataTypeList['issue']       = 'Issue';
$lang->resourcecalendars->dataTypeList['review']      = 'Review';
$lang->resourcecalendars->dataTypeList['productplan'] = 'Plan';
$lang->resourcecalendars->dataTypeList['auditplan']   = 'Audit Plan';
$lang->resourcecalendars->dataTypeList['nc']          = 'Non conformity';

$lang->resourcecalendars->attendTypeList['leave']    = 'Leave';
$lang->resourcecalendars->attendTypeList['makeup']   = 'Makeup';
$lang->resourcecalendars->attendTypeList['overtime'] = 'Overtime';
$lang->resourcecalendars->attendTypeList['lieu']     = 'Lieu';

$lang->resourcecalendars->dynamicTypeList['task']        = 'Task';
$lang->resourcecalendars->dynamicTypeList['story']       = $lang->SRCommon;
$lang->resourcecalendars->dynamicTypeList['requirement'] = $lang->URCommon;
$lang->resourcecalendars->dynamicTypeList['bug']         = 'Bug';
$lang->resourcecalendars->dynamicTypeList['todo']        = 'Todo';
$lang->resourcecalendars->dynamicTypeList['feedback']    = 'Feedback';
$lang->resourcecalendars->dynamicTypeList['ticket']      = 'Ticket';
$lang->resourcecalendars->dynamicTypeList['case']        = 'Test Case';
$lang->resourcecalendars->dynamicTypeList['productplan'] = 'Plan';
$lang->resourcecalendars->dynamicTypeList['project']     = 'Project';
$lang->resourcecalendars->dynamicTypeList['execution']   = $lang->execution->common;
$lang->resourcecalendars->dynamicTypeList['doc']         = 'Document';
$lang->resourcecalendars->dynamicTypeList['other']       = 'Other';

$lang->resourcecalendars->setHoursList[1] = 'On';
$lang->resourcecalendars->setHoursList[0] = 'Off';
