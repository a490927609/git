<?php
/* Field. */
$lang->resourcecalendars->common                 = '資源日曆';
$lang->resourcecalendars->dept                   = '部門';
$lang->resourcecalendars->user                   = '用戶';
$lang->resourcecalendars->role                   = '職位';
$lang->resourcecalendars->projectTeam            = '項目團隊';
$lang->resourcecalendars->date                   = '日期';
$lang->resourcecalendars->today                  = '今天';
$lang->resourcecalendars->to                     = '至';
$lang->resourcecalendars->search                 = '查詢';
$lang->resourcecalendars->consumeHoursPerDay     = '每日平均消耗工時';
$lang->resourcecalendars->loadRate               = '負載率';
$lang->resourcecalendars->loadRateCol            = '負載率(%)';
$lang->resourcecalendars->totalLoadRate          = '總負載率';
$lang->resourcecalendars->leave                  = '請假';
$lang->resourcecalendars->waitItem               = '待處理條目';
$lang->resourcecalendars->doneItem               = '記日誌條目';
$lang->resourcecalendars->waitCountCol           = '待處理條目數';
$lang->resourcecalendars->doneCountCol           = '記日誌條目數';
$lang->resourcecalendars->totalConsumeHoursCol   = '消耗總工時(h)';
$lang->resourcecalendars->totalEstimatedHours    = '未完成工作量';
$lang->resourcecalendars->totalEstimatedHoursCol = '未完成工作量(h)';
$lang->resourcecalendars->consumeHoursCol        = '消耗工時(h)';
$lang->resourcecalendars->estimatedHoursCol      = '預計剩餘(h)';
$lang->resourcecalendars->estimateHoursPerDay    = '每日平均預計工時';
$lang->resourcecalendars->loadRateCol            = '負載率(%)';
$lang->resourcecalendars->taskCountCol           = '任務數';
$lang->resourcecalendars->projectCol             = '項目';
$lang->resourcecalendars->deadlineCol            = '截止時間';
$lang->resourcecalendars->company                = '組織資源日曆';
$lang->resourcecalendars->person                 = '個人資源日曆';
$lang->resourcecalendars->showAll                = '查看所有人資源日曆';
$lang->resourcecalendars->setting                = '資源日曆設置';
$lang->resourcecalendars->wait                   = '待處理';
$lang->resourcecalendars->done                   = '已處理';
$lang->resourcecalendars->showHoliday            = '包含節假日';
$lang->resourcecalendars->setHours               = '設置工作時間';
$lang->resourcecalendars->setHoliday             = '設置節假日';
$lang->resourcecalendars->setLoad                = '設置負載區間';
$lang->resourcecalendars->setLoadAB              = '負載區間設置';
$lang->resourcecalendars->setPredictHours        = '設置每項預測工時';
$lang->resourcecalendars->future                 = '待定';
$lang->resourcecalendars->longTime               = '長期';
$lang->resourcecalendars->monthRange             = '{0} ~ {1}';
$lang->resourcecalendars->countUnit              = '{0}次';
$lang->resourcecalendars->dayCount               = '{0}天';
$lang->resourcecalendars->fullDate               = 'yyyy年MM月dd日';
$lang->resourcecalendars->yearDate               = 'yyyy年';
$lang->resourcecalendars->monthDate              = 'MM月dd日';
$lang->resourcecalendars->waitSummary            = '待處理條目數總計 <strong>%s</strong> 條，任務數總計 <strong>%s</strong> 項，剩餘總工時 <strong>%s</strong> h。';
$lang->resourcecalendars->doneSummary            = '記日誌條目數總計 <strong>%s</strong> 條，任務數總計 <strong>%s</strong> 項，消耗總工時 <strong>%s</strong> h。';
$lang->resourcecalendars->simulatedLoad          = '負載模擬';
$lang->resourcecalendars->simulatedExit          = '退出模擬';
$lang->resourcecalendars->taskHourPredict        = '任務類工時系統預測';
$lang->resourcecalendars->notTaskHourPredict     = '非任務類待辦項工時預測';
$lang->resourcecalendars->predictHoursTitle      = '每項預測工時';
$lang->resourcecalendars->totalAvailableHours    = '總可用工時';
$lang->resourcecalendars->day                    = '天';
$lang->resourcecalendars->totalWorkDays          = '總工作日';
$lang->resourcecalendars->defaultWorkhours       = '每天可用工時';
$lang->resourcecalendars->batchAdjust            = '整體調整';
$lang->resourcecalendars->dynamicType            = '動態類別';
$lang->resourcecalendars->actionTimes            = '操作次數';
$lang->resourcecalendars->clear                  = '清空';
$lang->resourcecalendars->workHours              = '人工預測工時';
$lang->resourcecalendars->predictHours           = '系統預測工時';
$lang->resourcecalendars->totalHours             = '預計剩餘工時總計';
$lang->resourcecalendars->workHoursPerDay        = '平均未完成工作量';
$lang->resourcecalendars->simulateConfirmTip     = '當前拖動包含 {0} 天節假日，期望加班';
$lang->resourcecalendars->makeupOverTimeTip      = '此數值超出節假日天數';
$lang->resourcecalendars->increaseWorkDays       = '增加{0}個工作日';
$lang->resourcecalendars->decreaseWorkDays       = '減少{0}個工作日';
$lang->resourcecalendars->deleted                = '已刪除';

/* Tip. */
$lang->resourcecalendars->rangeTip                = '此區間';
$lang->resourcecalendars->loadRangeTip            = '顏色與負載率區間';
$lang->resourcecalendars->imitateTip              =  '此功能可以模擬調整待處理工作的工期長短，同步查看負載率的變化';
$lang->resourcecalendars->holidayTip              = '節假日數據來源於後台自定義的任務設置中的單雙休的設置以及辦公模組中的節假日設置';
$lang->resourcecalendars->holidayTipForOpen       = '節假日數據來源於後台自定義的任務設置中的單雙休的設置';
$lang->resourcecalendars->userDeletedTip          = '該用戶已刪除。';
$lang->resourcecalendars->userNotExistTip         = '該用戶不存在。';
$lang->resourcecalendars->waitTaskCountTip        = '指派給當前用戶的，未開始和進行中的任務數之和';
$lang->resourcecalendars->doneTaskCountTip        = '當前用戶的填寫工時的任務的數量';
$lang->resourcecalendars->totalConsumeTip         = '員工填寫的日誌之和';
$lang->resourcecalendars->waitLoadRateTip         = '預計總工時/（每天可用工時*工作日天數）';
$lang->resourcecalendars->doneLoadRateTip         = '消耗總工時/（每天可用工時*工作日天數）';
$lang->resourcecalendars->openWaitCountTip        = '指派給當前用戶，需處理的任務、待辦、' . $lang->SRCommon . '、' . $lang->URCommon . '、bug、用例、測試單的總數';
$lang->resourcecalendars->bizWaitCountTip         = '指派給當前用戶，需處理的任務、待辦、' . $lang->SRCommon . '、' . $lang->URCommon . '、bug、用例、測試單、反饋、工單的總數';
$lang->resourcecalendars->maxWaitCountTip         = '指派給當前用戶，需處理的任務、待辦、' . $lang->SRCommon . '、' . $lang->URCommon . '、bug、用例、測試單、反饋、工單、問題、風險、評審、QA的總數';
$lang->resourcecalendars->openDoneCountTip        = '當前用戶在任務中填寫日誌的條目數';
$lang->resourcecalendars->bizDoneCountTip         = '當前用戶在任務、待辦、' . $lang->SRCommon . '、' . $lang->URCommon . '、bug、計劃、反饋、工單中填寫日誌的條目數';
$lang->resourcecalendars->maxDoneCountTip         = '當前用戶在任務、待辦、' . $lang->SRCommon . '、' . $lang->URCommon . '、bug、計劃、反饋、工單、問題、風險、評審中填寫日誌的條目數。';
$lang->resourcecalendars->batchAdjustTip          = '提示：拖動圓形滑塊可模擬修改工期，滑塊中展示內容為每天平均工時。';
$lang->resourcecalendars->waitWorkHoursTip        = '當前用戶在 <strong>{0}</strong> 個工作日中所有待處理條目的預計工時之和。<br>計算公式：未完成工作量 = 任務人工預測工時+任務系統預測工時+其他待辦項預測工時';
$lang->resourcecalendars->waitTaskWorkHoursTip    = '當前用戶在 <strong>{0}</strong> 個工作日中所有待處理條目的預計工時之和。<br>計算公式：未完成工作量 = 任務人工預測工時+任務系統預測工時';
$lang->resourcecalendars->waitNotTaskWorkHoursTip = '當前用戶在 <strong>{0}</strong> 個工作日中所有待處理條目的預計工時之和。<br>計算公式：未完成工作量 = 任務人工預測工時+其他待辦項預測工時';

$lang->resourcecalendars->openSetpredicthoursTip = <<<EOF
<div class='tip-title'><p>提示：<p></div>
<div class='tip-content'>
  <p>1.開啟後，資源日曆列表中展示預測工時的數值。</p>
  <p>2.任務類的系統預測工時根據每個人不同的效率進行計算。</p>
  <p>3.非任務類待辦項指{$lang->SRCommon}、{$lang->URCommon}、bug、待辦、用例、測試單、計劃。</p>
  <p>4.此處預設值為系統依據過往記錄推薦的平均值，您可以自行修改。</p>
  <p>5.系統推薦值存在不准確性。</p>
  <p>6.自行設置時注意考慮還需同時處理其他並發事項，可多預留些必要的緩衝時間。</p>
</div>
EOF;

$lang->resourcecalendars->bizSetpredicthoursTip = <<<EOF
<div class='tip-title'>提示：</div>
<div class='tip-content'>
  <p>1.開啟後，資源日曆列表中展示預測工時的數值。</p>
  <p>2.任務類的系統預測工時根據每個人不同的效率進行計算。</p>
  <p>3.非任務類待辦項指{$lang->SRCommon}、{$lang->URCommon}、bug、待辦、用例、測試單、計劃、反饋、工單。</p>
  <p>4.此處預設值為系統依據過往記錄推薦的平均值，您可以自行修改。</p>
  <p>5.系統推薦值存在不准確性。</p>
  <p>6.自行設置時注意考慮還需同時處理其他並發事項，可多預留些必要的緩衝時間。</p>
</div>
EOF;

$lang->resourcecalendars->maxSetpredicthoursTip = <<<EOF
<div class='tip-title'>提示：</div>
<div class='tip-content'>
  <p>1.開啟後，資源日曆列表中展示預測工時的數值。</p>
  <p>2.任務類的系統預測工時根據每個人不同的效率進行計算。</p>
  <p>3.非任務類待辦項指{$lang->SRCommon}、{$lang->URCommon}、bug、待辦、用例、測試單、計劃、反饋、工單、風險、問題、評審、QA。</p>
  <p>4.此處預設值為系統依據過往記錄推薦的平均值，您可以自行修改。</p>
  <p>5.系統推薦值存在不准確性。</p>
  <p>6.自行設置時注意考慮還需同時處理其他並發事項，可多預留些必要的緩衝時間。</p>
</div>
EOF;

$lang->resourcecalendars->monthNames = array('一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月');

$lang->resourcecalendars->weekDayNames[0] = '周一';
$lang->resourcecalendars->weekDayNames[1] = '周二';
$lang->resourcecalendars->weekDayNames[2] = '周三';
$lang->resourcecalendars->weekDayNames[3] = '周四';
$lang->resourcecalendars->weekDayNames[4] = '周五';
$lang->resourcecalendars->weekDayNames[5] = '周六';
$lang->resourcecalendars->weekDayNames[6] = '周日';

$lang->resourcecalendars->loadType['relax']   = '輕鬆';
$lang->resourcecalendars->loadType['spare']   = '有餘力';
$lang->resourcecalendars->loadType['normal']  = '正常';
$lang->resourcecalendars->loadType['full']    = '滿載';
$lang->resourcecalendars->loadType['over']    = '超載';
$lang->resourcecalendars->loadType['extreme'] = '過載';

$lang->resourcecalendars->searchType['day']   = '按天查看';
$lang->resourcecalendars->searchType['week']  = '按周查看';
$lang->resourcecalendars->searchType['month'] = '按月查看';

$lang->resourcecalendars->dataTypeList['task']        = '任務';
$lang->resourcecalendars->dataTypeList['todo']        = '待辦';
$lang->resourcecalendars->dataTypeList['bug']         = 'Bug';
$lang->resourcecalendars->dataTypeList['story']       = $lang->SRCommon;
$lang->resourcecalendars->dataTypeList['requirement'] = $lang->URCommon;
$lang->resourcecalendars->dataTypeList['testcase']    = '用例';
$lang->resourcecalendars->dataTypeList['testtask']    = '測試單';
$lang->resourcecalendars->dataTypeList['feedback']    = '反饋';
$lang->resourcecalendars->dataTypeList['ticket']      = '工單';
$lang->resourcecalendars->dataTypeList['risk']        = '風險';
$lang->resourcecalendars->dataTypeList['issue']       = '問題';
$lang->resourcecalendars->dataTypeList['review']      = '評審';
$lang->resourcecalendars->dataTypeList['productplan'] = '計劃';
$lang->resourcecalendars->dataTypeList['auditplan']   = '質量保證計劃';
$lang->resourcecalendars->dataTypeList['nc']          = '不符合項';

$lang->resourcecalendars->attendTypeList['leave']    = '請假';
$lang->resourcecalendars->attendTypeList['makeup']   = '補班';
$lang->resourcecalendars->attendTypeList['overtime'] = '加班';
$lang->resourcecalendars->attendTypeList['lieu']     = '調休';

$lang->resourcecalendars->dynamicTypeList['task']        = '任務';
$lang->resourcecalendars->dynamicTypeList['story']       = $lang->SRCommon;
$lang->resourcecalendars->dynamicTypeList['requirement'] = $lang->URCommon;
$lang->resourcecalendars->dynamicTypeList['bug']         = 'Bug';
$lang->resourcecalendars->dynamicTypeList['todo']        = '待辦';
$lang->resourcecalendars->dynamicTypeList['feedback']    = '反饋';
$lang->resourcecalendars->dynamicTypeList['ticket']      = '工單';
$lang->resourcecalendars->dynamicTypeList['case']        = '用例';
$lang->resourcecalendars->dynamicTypeList['productplan'] = '計劃';
$lang->resourcecalendars->dynamicTypeList['project']     = '項目';
$lang->resourcecalendars->dynamicTypeList['execution']   = $lang->execution->common;
$lang->resourcecalendars->dynamicTypeList['doc']         = '文檔';
$lang->resourcecalendars->dynamicTypeList['other']       = '其他';

$lang->resourcecalendars->setHoursList[1] = '開啟';
$lang->resourcecalendars->setHoursList[0] = '關閉';
