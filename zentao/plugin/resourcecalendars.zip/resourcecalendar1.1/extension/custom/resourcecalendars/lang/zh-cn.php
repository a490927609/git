<?php
/* Field. */
$lang->resourcecalendars->common                 = '资源日历';
$lang->resourcecalendars->dept                   = '部门';
$lang->resourcecalendars->user                   = '用户';
$lang->resourcecalendars->role                   = '职位';
$lang->resourcecalendars->projectTeam            = '项目团队';
$lang->resourcecalendars->date                   = '日期';
$lang->resourcecalendars->today                  = '今天';
$lang->resourcecalendars->to                     = '至';
$lang->resourcecalendars->search                 = '查询';
$lang->resourcecalendars->consumeHoursPerDay     = '每日平均消耗工时';
$lang->resourcecalendars->loadRate               = '负载率';
$lang->resourcecalendars->loadRateCol            = '负载率(%)';
$lang->resourcecalendars->totalLoadRate          = '总负载率';
$lang->resourcecalendars->leave                  = '请假';
$lang->resourcecalendars->waitItem               = '待处理条目';
$lang->resourcecalendars->doneItem               = '记日志条目';
$lang->resourcecalendars->waitCountCol           = '待处理条目数';
$lang->resourcecalendars->doneCountCol           = '记日志条目数';
$lang->resourcecalendars->totalConsumeHoursCol   = '消耗总工时(h)';
$lang->resourcecalendars->totalEstimatedHours    = '未完成工作量';
$lang->resourcecalendars->totalEstimatedHoursCol = '未完成工作量(h)';
$lang->resourcecalendars->consumeHoursCol        = '消耗工时(h)';
$lang->resourcecalendars->estimatedHoursCol      = '预计剩余(h)';
$lang->resourcecalendars->estimateHoursPerDay    = '每日平均预计工时';
$lang->resourcecalendars->loadRateCol            = '负载率(%)';
$lang->resourcecalendars->taskCountCol           = '任务数';
$lang->resourcecalendars->projectCol             = '项目';
$lang->resourcecalendars->deadlineCol            = '截止时间';
$lang->resourcecalendars->company                = '组织资源日历';
$lang->resourcecalendars->person                 = '个人资源日历';
$lang->resourcecalendars->showAll                = '查看所有人资源日历';
$lang->resourcecalendars->setting                = '资源日历设置';
$lang->resourcecalendars->wait                   = '待处理';
$lang->resourcecalendars->done                   = '已处理';
$lang->resourcecalendars->showHoliday            = '包含节假日';
$lang->resourcecalendars->setHours               = '设置工作时间';
$lang->resourcecalendars->setHoliday             = '设置节假日';
$lang->resourcecalendars->setLoad                = '设置负载区间';
$lang->resourcecalendars->setLoadAB              = '负载区间设置';
$lang->resourcecalendars->setPredictHours        = '设置每项预测工时';
$lang->resourcecalendars->future                 = '待定';
$lang->resourcecalendars->longTime               = '长期';
$lang->resourcecalendars->monthRange             = '{0} ~ {1}';
$lang->resourcecalendars->countUnit              = '{0}次';
$lang->resourcecalendars->dayCount               = '{0}天';
$lang->resourcecalendars->fullDate               = 'yyyy年MM月dd日';
$lang->resourcecalendars->yearDate               = 'yyyy年';
$lang->resourcecalendars->monthDate              = 'MM月dd日';
$lang->resourcecalendars->waitSummary            = '待处理条目数总计 <strong>%s</strong> 条，任务数总计 <strong>%s</strong> 项，未完成工作量 <strong>%s</strong> h。';
$lang->resourcecalendars->doneSummary            = '记日志条目数总计 <strong>%s</strong> 条，任务数总计 <strong>%s</strong> 项，消耗总工时 <strong>%s</strong> h。';
$lang->resourcecalendars->simulatedLoad          = '负载模拟';
$lang->resourcecalendars->simulatedExit          = '退出模拟';
$lang->resourcecalendars->taskHourPredict        = '任务类工时系统预测';
$lang->resourcecalendars->notTaskHourPredict     = '非任务类待办项工时预测';
$lang->resourcecalendars->predictHoursTitle      = '每项预测工时';
$lang->resourcecalendars->totalAvailableHours    = '总可用工时';
$lang->resourcecalendars->day                    = '天';
$lang->resourcecalendars->totalWorkDays          = '总工作日';
$lang->resourcecalendars->defaultWorkhours       = '每天可用工时';
$lang->resourcecalendars->batchAdjust            = '整体调整';
$lang->resourcecalendars->dynamicType            = '动态类别';
$lang->resourcecalendars->actionTimes            = '操作次数';
$lang->resourcecalendars->clear                  = '清空';
$lang->resourcecalendars->workHours              = '人工预测工时';
$lang->resourcecalendars->predictHours           = '系统预测工时';
$lang->resourcecalendars->totalHours             = '预计剩余工时总计';
$lang->resourcecalendars->workHoursPerDay        = '平均未完成工作量';
$lang->resourcecalendars->simulateConfirmTip     = '当前拖动包含 {0} 天节假日，期望加班';
$lang->resourcecalendars->makeupOverTimeTip      = '此数值超出节假日天数';
$lang->resourcecalendars->increaseWorkDays       = '增加{0}个工作日';
$lang->resourcecalendars->decreaseWorkDays       = '减少{0}个工作日';
$lang->resourcecalendars->deleted                = '已删除';

/* Tip. */
$lang->resourcecalendars->rangeTip                = '此区间';
$lang->resourcecalendars->loadRangeTip            = '颜色与负载率区间';
$lang->resourcecalendars->imitateTip              =  '此功能可以模拟调整待处理工作的工期长短，同步查看负载率的变化';
$lang->resourcecalendars->holidayTip              = '节假日数据来源于后台自定义的任务设置中的单双休的设置以及办公模块中的节假日设置';
$lang->resourcecalendars->holidayTipForOpen       = '节假日数据来源于后台自定义的任务设置中的单双休的设置';
$lang->resourcecalendars->userDeletedTip          = '该用户已删除。';
$lang->resourcecalendars->userNotExistTip         = '该用户不存在。';
$lang->resourcecalendars->waitTaskCountTip        = '指派给当前用户的，未开始和进行中的任务数之和';
$lang->resourcecalendars->doneTaskCountTip        = '当前用户的填写工时的任务的数量';
$lang->resourcecalendars->totalConsumeTip         = '员工填写的日志之和';
$lang->resourcecalendars->waitLoadRateTip         = '预计总工时/（每天可用工时*工作日天数）';
$lang->resourcecalendars->doneLoadRateTip         = '消耗总工时/（每天可用工时*工作日天数）';
$lang->resourcecalendars->openWaitCountTip        = '指派给当前用户，需处理的任务、待办、' . $lang->SRCommon . '、' . $lang->URCommon . '、bug、用例、测试单的总数';
$lang->resourcecalendars->bizWaitCountTip         = '指派给当前用户，需处理的任务、待办、' . $lang->SRCommon . '、' . $lang->URCommon . '、bug、用例、测试单、反馈、工单的总数';
$lang->resourcecalendars->maxWaitCountTip         = '指派给当前用户，需处理的任务、待办、' . $lang->SRCommon . '、' . $lang->URCommon . '、bug、用例、测试单、反馈、工单、问题、风险、评审、QA的总数';
$lang->resourcecalendars->openDoneCountTip        = '当前用户在任务中填写日志的条目数';
$lang->resourcecalendars->bizDoneCountTip         = '当前用户在任务、待办、' . $lang->SRCommon . '、' . $lang->URCommon . '、bug、计划、反馈、工单中填写日志的条目数';
$lang->resourcecalendars->maxDoneCountTip         = '当前用户在任务、待办、' . $lang->SRCommon . '、' . $lang->URCommon . '、bug、计划、反馈、工单、问题、风险、评审中填写日志的条目数。';
$lang->resourcecalendars->batchAdjustTip          = '提示：拖动圆形滑块可模拟修改工期，滑块中展示内容为每天平均工时。';
$lang->resourcecalendars->waitWorkHoursTip        = '当前用户在 <strong>{0}</strong> 个工作日中所有待处理条目的预计工时之和。<br>计算公式：未完成工作量 = 任务人工预测工时+任务系统预测工时+其他待办项预测工时';
$lang->resourcecalendars->waitTaskWorkHoursTip    = '当前用户在 <strong>{0}</strong> 个工作日中所有待处理条目的预计工时之和。<br>计算公式：未完成工作量 = 任务人工预测工时+任务系统预测工时';
$lang->resourcecalendars->waitNotTaskWorkHoursTip = '当前用户在 <strong>{0}</strong> 个工作日中所有待处理条目的预计工时之和。<br>计算公式：未完成工作量 = 任务人工预测工时+其他待办项预测工时';

$lang->resourcecalendars->openSetpredicthoursTip = <<<EOF
<div class='tip-title'><p>提示：<p></div>
<div class='tip-content'>
  <p>1.开启后，资源日历列表中展示预测工时的数值。</p>
  <p>2.任务类的系统预测工时根据每个人不同的效率进行计算。</p>
  <p>3.非任务类待办项指{$lang->SRCommon}、{$lang->URCommon}、bug、待办、用例、测试单、计划。</p>
  <p>4.此处默认值为系统依据过往记录推荐的平均值，您可以自行修改。</p>
  <p>5.系统推荐值存在不准确性。</p>
  <p>6.自行设置时注意考虑还需同时处理其他并发事项，可多预留些必要的缓冲时间。</p>
</div>
EOF;

$lang->resourcecalendars->bizSetpredicthoursTip = <<<EOF
<div class='tip-title'>提示：</div>
<div class='tip-content'>
  <p>1.开启后，资源日历列表中展示预测工时的数值。</p>
  <p>2.任务类的系统预测工时根据每个人不同的效率进行计算。</p>
  <p>3.非任务类待办项指{$lang->SRCommon}、{$lang->URCommon}、bug、待办、用例、测试单、计划、反馈、工单。</p>
  <p>4.此处默认值为系统依据过往记录推荐的平均值，您可以自行修改。</p>
  <p>5.系统推荐值存在不准确性。</p>
  <p>6.自行设置时注意考虑还需同时处理其他并发事项，可多预留些必要的缓冲时间。</p>
</div>
EOF;

$lang->resourcecalendars->maxSetpredicthoursTip = <<<EOF
<div class='tip-title'>提示：</div>
<div class='tip-content'>
  <p>1.开启后，资源日历列表中展示预测工时的数值。</p>
  <p>2.任务类的系统预测工时根据每个人不同的效率进行计算。</p>
  <p>3.非任务类待办项指{$lang->SRCommon}、{$lang->URCommon}、bug、待办、用例、测试单、计划、反馈、工单、风险、问题、评审、QA。</p>
  <p>4.此处默认值为系统依据过往记录推荐的平均值，您可以自行修改。</p>
  <p>5.系统推荐值存在不准确性。</p>
  <p>6.自行设置时注意考虑还需同时处理其他并发事项，可多预留些必要的缓冲时间。</p>
</div>
EOF;

$lang->resourcecalendars->monthNames = array('一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月');

$lang->resourcecalendars->weekDayNames[0] = '周一';
$lang->resourcecalendars->weekDayNames[1] = '周二';
$lang->resourcecalendars->weekDayNames[2] = '周三';
$lang->resourcecalendars->weekDayNames[3] = '周四';
$lang->resourcecalendars->weekDayNames[4] = '周五';
$lang->resourcecalendars->weekDayNames[5] = '周六';
$lang->resourcecalendars->weekDayNames[6] = '周日';

$lang->resourcecalendars->loadType['relax']   = '轻松';
$lang->resourcecalendars->loadType['spare']   = '有余力';
$lang->resourcecalendars->loadType['normal']  = '正常';
$lang->resourcecalendars->loadType['full']    = '满载';
$lang->resourcecalendars->loadType['over']    = '超载';
$lang->resourcecalendars->loadType['extreme'] = '过载';

$lang->resourcecalendars->searchType['day']   = '按天查看';
$lang->resourcecalendars->searchType['week']  = '按周查看';
$lang->resourcecalendars->searchType['month'] = '按月查看';

$lang->resourcecalendars->dataTypeList['task']        = '任务';
$lang->resourcecalendars->dataTypeList['todo']        = '待办';
$lang->resourcecalendars->dataTypeList['bug']         = 'Bug';
$lang->resourcecalendars->dataTypeList['story']       = $lang->SRCommon;
$lang->resourcecalendars->dataTypeList['requirement'] = $lang->URCommon;
$lang->resourcecalendars->dataTypeList['testcase']    = '用例';
$lang->resourcecalendars->dataTypeList['testtask']    = '测试单';
$lang->resourcecalendars->dataTypeList['feedback']    = '反馈';
$lang->resourcecalendars->dataTypeList['ticket']      = '工单';
$lang->resourcecalendars->dataTypeList['risk']        = '风险';
$lang->resourcecalendars->dataTypeList['issue']       = '问题';
$lang->resourcecalendars->dataTypeList['review']      = '评审';
$lang->resourcecalendars->dataTypeList['productplan'] = '计划';
$lang->resourcecalendars->dataTypeList['auditplan']   = '质量保证计划';
$lang->resourcecalendars->dataTypeList['nc']          = '不符合项';

$lang->resourcecalendars->attendTypeList['leave']    = '请假';
$lang->resourcecalendars->attendTypeList['makeup']   = '补班';
$lang->resourcecalendars->attendTypeList['overtime'] = '加班';
$lang->resourcecalendars->attendTypeList['lieu']     = '调休';

$lang->resourcecalendars->dynamicTypeList['task']        = '任务';
$lang->resourcecalendars->dynamicTypeList['story']       = $lang->SRCommon;
$lang->resourcecalendars->dynamicTypeList['requirement'] = $lang->URCommon;
$lang->resourcecalendars->dynamicTypeList['bug']         = 'Bug';
$lang->resourcecalendars->dynamicTypeList['todo']        = '待办';
$lang->resourcecalendars->dynamicTypeList['feedback']    = '反馈';
$lang->resourcecalendars->dynamicTypeList['ticket']      = '工单';
$lang->resourcecalendars->dynamicTypeList['case']        = '用例';
$lang->resourcecalendars->dynamicTypeList['productplan'] = '计划';
$lang->resourcecalendars->dynamicTypeList['project']     = '项目';
$lang->resourcecalendars->dynamicTypeList['execution']   = $lang->execution->common;
$lang->resourcecalendars->dynamicTypeList['doc']         = '文档';
$lang->resourcecalendars->dynamicTypeList['other']       = '其他';

$lang->resourcecalendars->setHoursList[1] = '开启';
$lang->resourcecalendars->setHoursList[0] = '关闭';
