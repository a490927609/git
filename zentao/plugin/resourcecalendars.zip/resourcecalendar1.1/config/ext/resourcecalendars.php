<?php
$config->openMethods[] = 'resourcecalendars.sethours';

$filter->resourcecalendars = new stdclass();
$filter->resourcecalendars->default = new stdclass();
$filter->resourcecalendars->default->cookie['showHoliday'] = 'code';

$filter->resourcecalendars = new stdclass();
$filter->resourcecalendars->default = new stdclass();
$filter->resourcecalendars->default->cookie['searchType'] = 'code';
