<?php
global $lang;
$config->testcase->search['params']['lastRunResult']  = array('operator' => '=', 'control' => 'select', 'values' => array('' => '') + $lang->testcase->resultList + array('null' => $lang->testcase->unexecuted));
