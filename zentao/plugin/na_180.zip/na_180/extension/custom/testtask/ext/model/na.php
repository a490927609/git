<?php
/**
 * Create test result
 *
 * @param  int   $runID
 * @access public
 * @return void
 */
public function createResult($runID = 0)
{
    /* Compute the test result.
     *
     * 1. if there result in the post, use it.
     * 2. if no result, set default is pass.
     * 3. then check the steps to compute result.
     *
     * */
    $postData   = fixer::input('post')->get();
    $caseResult = isset($postData->result) ? $postData->result : 'pass';
    if(isset($postData->steps) and $postData->steps)
    {
        $countArray = array_count_values($postData->steps);
        if($countArray['n/a'] == count($postData->steps))
        {
            $caseResult = 'n/a';
        }
        else
        {
            foreach($postData->steps as $stepID => $stepResult)
            {
                if($stepResult != 'pass' and $stepResult != 'n/a') $caseResult = $stepResult;
                if($stepResult == 'fail')
                {
                    $caseResult = $stepResult;
                    break;
                }
            }
        }
    }

    /* Create result of every step. */
    foreach($postData->steps as $stepID =>$stepResult)
    {
        $step['result'] = $stepResult;
        $step['real']   = $postData->reals[$stepID];
        $stepResults[$stepID] = $step;
    }

    /* Insert into testResult table. */
    $now = helper::now();
    $result = fixer::input('post')
        ->add('run', $runID)
        ->add('caseResult', $caseResult)
        ->setForce('stepResults', serialize($stepResults))
        ->setDefault('lastRunner', $this->app->user->account)
        ->setDefault('date', $now)
        ->skipSpecial('stepResults')
        ->remove('steps,reals,result')
        ->get();

    /* Remove files and labels field when uploading files for case result or step result. */
    foreach($result as $fieldName => $field)
    {
        if((strpos($fieldName, 'files') !== false) or (strpos($fieldName, 'labels') !== false)) unset($result->$fieldName);
    }

    $this->dao->insert(TABLE_TESTRESULT)->data($result)->autoCheck()->exec();

    /* Save upload files for case result or step result. */
    if(!dao::isError())
    {
        $resultID = $this->dao->lastInsertID();
        foreach($stepResults as $stepID => $stepResult) $this->loadModel('file')->saveUpload('stepResult', $resultID, $stepID, "files{$stepID}", "labels{$stepID}");
    }
    $this->dao->update(TABLE_CASE)->set('lastRunner')->eq($this->app->user->account)->set('lastRunDate')->eq($now)->set('lastRunResult')->eq($caseResult)->where('id')->eq($postData->case)->exec();

    if($runID)
    {
        /* Update testRun's status. */
        if(!dao::isError())
        {
            $runStatus = $caseResult == 'blocked' ? 'blocked' : 'normal';
            $this->dao->update(TABLE_TESTRUN)
                ->set('lastRunResult')->eq($caseResult)
                ->set('status')->eq($runStatus)
                ->set('lastRunner')->eq($this->app->user->account)
                ->set('lastRunDate')->eq($now)
                ->where('id')->eq($runID)
                ->exec();
        }
    }

    if(!dao::isError()) $this->loadModel('score')->create('testtask', 'runCase', $runID);

    return $caseResult;
}

/**
 * Process $_POST.
 *
 * @access public
 * @return void
 */
public function processPost()
{
    if(empty($_POST['results'])) return;

    $naCases = array();
    foreach($_POST['results'] as $id => $result)
    {
        if($result == 'n/a') $naCases[] = $id;
    }

    foreach($naCases as $caseID)
    {
        foreach($_POST['steps'][$caseID] as $stepID => $step)
        {
            $_POST['steps'][$caseID][$stepID] = 'n/a';
        }
    }
}

/**
 * Expand batch run method.
 *
 * @param  string $runCaseType
 * @param  int    $taskID
 * @access public
 * @return void
 */
public function batchRun($runCaseType = 'testcase', $taskID = 0)
{
    $this->processPost();
    parent::batchRun($runCaseType, $taskID);
}
