<script>
$(function()
{
    $('#mainContent > form > table > tbody > tr:not(:last)').each(function(index, element){
        var caseID = $(this).children('td:eq(0)').text();
        var name = 'results[' + parseInt(caseID) + ']';
        var id = name + 'n/a';
        var radio = $(this).children('td:eq(4)').children(':first').children().children().clone().attr('id', id).attr('name', name).attr('checked', false).attr('value','n/a');
        var radioDiv = '<div class="radio"><label>' + radio[0].outerHTML + '忽略</label></div>';
        $(this).children('td:eq(4)').append($(radioDiv));
    });
});
</script>
