<?php
$lang->testtask->showFail = '失败<span class="text-danger">%s</span>次 忽略<span>%s</span>次';
