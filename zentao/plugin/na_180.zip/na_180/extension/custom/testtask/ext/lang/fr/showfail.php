<?php
$lang->testtask->showFail = 'Failed <span class="text-danger">%s</span> times Ignored <span>%s</span> times';

