<?php
$lang->testtask->showFail = '失敗<span class="text-danger">%s</span>次 忽略<span>%s</span>次';
