<?php
$lang->testreport->caseSummary     = '共有<strong>%s</strong>個用例，共執行<strong>%s</strong>個用例，產生了<strong>%s</strong>個結果，失敗的用例有<stron g> %s</strong>個，忽略的用例有<strong>%s</strong>個。';
