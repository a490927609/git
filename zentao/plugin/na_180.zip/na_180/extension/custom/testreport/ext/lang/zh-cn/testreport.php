<?php
$lang->testreport->caseSummary     = '共有<strong>%s</strong>个用例，共执行<strong>%s</strong>个用例，产生了<strong>%s</strong>个结果，失败的用例有<strong>  %s</strong>个，忽略的用例有<strong>%s</strong>个。';
