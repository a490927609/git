<?php
/**
 * Get result summary.
 *
 * @param  array    $tasks
 * @param  array    $cases
 * @param  string   $begin
 * @param  string   $end
 * @access public
 * @return string
 */
public function getResultSummary($tasks, $cases, $begin, $end)
{
    $caseCount = 0;
    $casesList = array();
    foreach($cases as $taskID => $caseList)
    {
        foreach($caseList as $caseID => $case)
        {
            $casesList[$caseID] = $case;
            $caseCount++;
        }
    }

    $results = $this->dao->select('t1.*')->from(TABLE_TESTRESULT)->alias('t1')
        ->leftJoin(TABLE_TESTRUN)->alias('t2')->on('t1.run=t2.id')
        ->where('t2.task')->in(array_keys($tasks))
        ->andWhere('t1.`case`')->in(array_keys($casesList))
        ->andWhere('t1.date')->ge($begin)
        ->andWhere('t1.date')->le($end . " 23:59:59")
        ->orderBy('date')
        ->fetchAll('id');

    $failResults   = 0;
    $ignoreResults = 0;
    $runCasesNum = array();
    foreach($results as $result) $runCasesNum[$result->run] = $result->caseResult;
    foreach($runCasesNum as $lastResult)
    {
        if($lastResult == 'fail') $failResults++;
        if($lastResult == 'n/a')  $ignoreResults++;
    }

    return sprintf($this->lang->testreport->caseSummary, $caseCount, count($runCasesNum), count($results), $failResults, $ignoreResults);
}
