<?php
public function authorize($account)
{
    $rights = parent::authorize($account);
    $rights['rights']['report']['annualdata'] = true;

    return $rights;
}
