<?php
/**
 * Get user login count in this year.
 * 
 * @param  array  $accounts
 * @param  int    $year 
 * @access public
 * @return int
 */
public function getUserYearLogins($accounts, $year)
{
    return $this->dao->select('count(*) as count')->from(TABLE_ACTION)->where('actor')->in($accounts)->andWhere('LEFT(date, 4)')->eq($year)->andWhere('action')->eq('login')->fetch('count');
}

/**
 * Get user action count in this year.
 * 
 * @param  array  $accounts 
 * @param  int    $year 
 * @access public
 * @return int
 */
public function getUserYearActions($accounts, $year)
{
    return $this->dao->select('count(*) as count')->from(TABLE_ACTION)
        ->where('LEFT(date, 4)')->eq($year)
        ->beginIF($accounts)->andWhere('actor')->in($accounts)->fi()
        ->fetch('count');
}

/**
 * Get user contributions in this year.
 * 
 * @param  array  $accounts 
 * @param  int    $year 
 * @access public
 * @return array
 */
public function getUserYearContributions($accounts, $year)
{
    $actionGroups = array();
    foreach($this->config->report->annualData['contributions'] as $objectType => $actions)
    {
        $table = $this->config->objectTables[$objectType];
        $actionGroups[$objectType] = $this->dao->select('t1.*')->from(TABLE_ACTION)->alias('t1')
        ->leftJoin($table)->alias('t2')->on("t1.objectType='$objectType' && t1.objectID=t2.id")
        ->where('LEFT(t1.date, 4)')->eq($year)
        ->andWhere('t1.objectType')->eq($objectType)
        ->andWhere('t1.action')->in(array_keys($actions))
        ->andWhere('t2.deleted')->eq(0)
        ->beginIF($accounts)->andWhere('t1.actor')->in($accounts)->fi()
        ->fetchAll('id');
    }

    $contributions = array();
    foreach($actionGroups as $objectType => $actions)
    {
        foreach($actions as $action)
        {
            $lowerAction = strtolower($action->action);
            if(!isset($this->config->report->annualData['contributions'][$objectType][$lowerAction])) continue;

            $actionName = $this->config->report->annualData['contributions'][$objectType][$lowerAction];

            $type = ($actionName == 'svnCommit' or $actionName == 'gitCommit') ? 'repo' : $objectType;
            if(!isset($contributions[$type][$actionName])) $contributions[$type][$actionName] = 0;
            $contributions[$type][$actionName] += 1;
        }
    }

    $contributions['case']['run'] = $this->dao->select('count(*) as count')->from(TABLE_TESTRESULT)->alias('t1')
        ->leftJoin(TABLE_CASE)->alias('t2')->on('t1.case=t2.id')
        ->where('LEFT(t1.date, 4)')->eq($year)
        ->andWhere('t2.deleted')->eq(0)
        ->beginIF($accounts)->andWhere('t1.lastRunner')->in($accounts)->fi()
        ->fetch('count');

    return $contributions;
}

/**
 * Get user todo stat in this year.
 * 
 * @param  array  $accounts
 * @param  int    $year 
 * @access public
 * @return object
 */
public function getUserYearTodos($accounts, $year)
{
    return $this->dao->select("count(*) as count, sum(if((`status` != 'done'), 1, 0)) AS `undone`, sum(if((`status` = 'done'), 1, 0)) AS `done`")->from(TABLE_TODO)
        ->where('LEFT(date, 4)')->eq($year)
        ->beginIF($accounts)->andWhere('account')->in($accounts)->fi()
        ->fetch();
}

/**
 * Get user effort stat in this error.
 * 
 * @param  array  $accounts
 * @param  int    $year 
 * @access public
 * @return object
 */
public function getUserYearEfforts($accounts, $year)
{
    $effort = $this->dao->select('count(*) as count, sum(consumed) as consumed')->from(TABLE_TASKESTIMATE)
        ->where('LEFT(date, 4)')->eq($year)
        ->beginIF($accounts)->andWhere('account')->in($accounts)->fi()
        ->fetch();

    $effort->consumed = round($effort->consumed, 2);
    return $effort;
}

/**
 * Get count of created story,plan and finished story by accounts every product in this year.
 * 
 * @param  array  $accounts
 * @param  int    $year 
 * @access public
 * @return array
 */
public function getUserYearProducts($accounts, $year)
{
    /* Get changed products in this year. */
    $products = $this->dao->select('id,name')->from(TABLE_PRODUCT)
        ->where('deleted')->eq(0)
        ->andWhere('LEFT(createdDate, 4)')->eq($year)
        ->beginIF($accounts)
        ->andWhere('createdBy', true)->in($accounts)
        ->orWhere('PO')->in($accounts)
        ->orWhere('QD')->in($accounts)
        ->orWhere('RD')->in($accounts)
        ->markRight(1)
        ->fi()
        ->fetchAll('id');

    /* Get created plans in this year. */
    $plans = $this->dao->select('t1.id,t1.product')->from(TABLE_PRODUCTPLAN)->alias('t1')
        ->leftJoin(TABLE_ACTION)->alias('t2')->on("t1.id=t2.objectID and t2.objectType='productplan'")
        ->where('LEFT(t2.date, 4)')->eq($year)
        ->andWhere('t1.deleted')->eq(0)
        ->beginIF($accounts)
        ->andWhere('t2.actor')->in($accounts)
        ->fi()
        ->andWhere('t2.action')->eq('opened')
        ->fetchAll();

    $planProducts = array();
    $planGroups   = array();
    foreach($plans as $plan)
    {
        $planProducts[$plan->product] = $plan->product;
        $planGroups[$plan->product][$plan->id] = $plan->id;
    }

    $createStoryProducts = $this->dao->select('DISTINCT product')->from(TABLE_STORY)
        ->where('LEFT(openedDate, 4)')->eq($year)
        ->andWhere('deleted')->eq(0)
        ->beginIF($accounts)->andWhere('openedBy')->in($accounts)->fi()
        ->fetchPairs('product', 'product');
    $closeStoryProducts  = $this->dao->select('DISTINCT product')->from(TABLE_STORY)
        ->where('LEFT(closedDate, 4)')->eq($year)
        ->andWhere('deleted')->eq(0)
        ->beginIF($accounts)->andWhere('closedBy')->in($accounts)->fi()
        ->fetchPairs('product', 'product');
    if($createStoryProducts or $closeStoryProducts)
    {
        $products += $this->dao->select('id,name')->from(TABLE_PRODUCT)
            ->where('id')->in($createStoryProducts + $closeStoryProducts + $planProducts)
            ->andWhere('deleted')->eq(0)
            ->fetchAll('id');
    }

    $createdStoryStats = $this->dao->select("product,sum(if((type = 'requirement'), 1, 0)) as requirement, sum(if((type = 'story'), 1, 0)) as story")->from(TABLE_STORY)
        ->where('product')->in(array_keys($products))
        ->andWhere('deleted')->eq(0)
        ->andWhere('LEFT(openedDate, 4)')->eq($year)
        ->beginIF($accounts)->andWhere('openedBy')->in($accounts)->fi()
        ->groupBy('product')
        ->fetchAll('product');

    $closedStoryStats = $this->dao->select("product,sum(if((status = 'closed'), 1, 0)) as finished")->from(TABLE_STORY)
        ->where('product')->in(array_keys($products))
        ->andWhere('deleted')->eq(0)
        ->andWhere('LEFT(closedDate, 4)')->eq($year)
        ->beginIF($accounts)->andWhere('closedBy')->in($accounts)->fi()
        ->groupBy('product')
        ->fetchAll('product');

    /* Merge created plan, created story and finished story in every product. */
    foreach($products as $productID => $product)
    {
        $product->plan        = 0;
        $product->requirement = 0;
        $product->story       = 0;
        $product->finished    = 0;

        $plans = zget($planGroups, $productID, array());
        if($plans) $product->plan = count($plans);

        $createdStoryStat = zget($createdStoryStats, $productID, '');
        if($createdStoryStat)
        {
            $product->requirement = $createdStoryStat->requirement;
            $product->story       = $createdStoryStat->story;
        }

        $closedStoryStat = zget($closedStoryStats, $productID, '');
        if($closedStoryStat) $product->finished = $closedStoryStat->finished;
    }

    return $products;
}

/**
 * Get count of finished task, story and resolved bug by accounts every projects in this year.
 * 
 * @param  array  $accounts
 * @param  int    $year 
 * @access public
 * @return array
 */
public function getUserYearProjects($accounts, $year)
{
    /* Get changed projects in this year. */
    $projects = $this->dao->select('id,name')->from(TABLE_PROJECT)->where('deleted')->eq(0)
        ->andWhere('LEFT(begin, 4)', true)->eq($year)
        ->orWhere('LEFT(end, 4)')->eq($year)
        ->markRight(1)
        ->beginIF($accounts)
        ->andWhere('openedBy', true)->in($accounts)
        ->orWhere('PO')->in($accounts)
        ->orWhere('PM')->in($accounts)
        ->orWhere('QD')->in($accounts)
        ->orWhere('RD')->in($accounts)
        ->markRight(1)
        ->fi()
        ->orderBy('`order` desc')
        ->fetchAll('id');

    $teamProjects = $this->dao->select('*')->from(TABLE_TEAM)
        ->where('type')->eq('project')
        ->beginIF($accounts)->andWhere('account')->in($accounts)->fi()
        ->andWhere('LEFT(`join`, 4)')->eq($year)
        ->fetchPairs('root', 'root');
    $taskProjects = $this->dao->select('project')->from(TABLE_TASK)
        ->where('LEFT(finishedDate, 4)')->eq($year)
        ->andWhere('deleted')->eq(0)
        ->beginIF($accounts)->andWhere('finishedBy')->in($accounts)->fi()
        ->fetchPairs('project', 'project');
    if($teamProjects or $taskProjects)
    {
        $projects += $this->dao->select('id,name')->from(TABLE_PROJECT)
            ->where('id')->in($teamProjects + $taskProjects)
            ->andWhere('deleted')->eq(0)
            ->orderBy('`order` desc')
            ->fetchAll('id');
    }

    /* Get count of finished task, story and resolved bug in this year. */
    $taskStats = $this->dao->select('project, count(*) as finishedTask, sum(if((story != 0), 1, 0)) as finishedStory')->from(TABLE_TASK)
        ->where('project')->in(array_keys($projects))
        ->andWhere('finishedBy')->ne('')
        ->andWhere('LEFT(finishedDate, 4)')->eq($year)
        ->andWhere('deleted')->eq(0)
        ->beginIF($accounts)->andWhere('finishedBy')->in($accounts)->fi()
        ->groupBy('project')
        ->fetchAll('project');
    $resolvedBugs = $this->dao->select('t2.project, count(*) as count')->from(TABLE_BUG)->alias('t1')
        ->leftJoin(TABLE_BUILD)->alias('t2')->on('t1.resolvedBuild=t2.id')
        ->where('t2.project')->in(array_keys($projects))
        ->andWhere('t1.resolvedBy')->ne('')
        ->andWhere('t1.deleted')->eq(0)
        ->andWhere('LEFT(t1.resolvedDate, 4)')->eq($year)
        ->beginIF($accounts)->andWhere('t1.resolvedBy')->in($accounts)->fi()
        ->groupBy('t2.project')
        ->fetchAll('project');

    foreach($projects as $projectID => $project)
    {
        $project->task  = 0;
        $project->story = 0;
        $project->bug   = 0;

        $taskStat = zget($taskStats, $projectID, '');
        if($taskStat)
        {
            $project->task  = $taskStat->finishedTask;
            $project->story = $taskStat->finishedStory;
        }

        $resolvedBug = zget($resolvedBugs, $projectID, '');
        if($resolvedBug) $project->bug = $resolvedBug->count;
    }

    return $projects;
}

/**
 * Get status stat that is all time, include story, task and bug. 
 * 
 * @access public
 * @return array
 */
public function getAllTimeStatusStat()
{
    $statusStat = array();
    $statusStat['story'] = $this->dao->select('status, count(status) as count')->from(TABLE_STORY)->where('deleted')->eq(0)->andWhere('type')->eq('story')->groupBy('status')->fetchPairs('status', 'count');
    $statusStat['task']  = $this->dao->select('status, count(status) as count')->from(TABLE_TASK)->where('deleted')->eq(0)->groupBy('status')->fetchPairs('status', 'count');
    $statusStat['bug']   = $this->dao->select('status, count(status) as count')->from(TABLE_BUG)->where('deleted')->eq(0)->groupBy('status')->fetchPairs('status', 'count');

    return $statusStat;
}

/**
 * Get year object stat, include status and action stat
 * 
 * @param  array  $accounts 
 * @param  string $year 
 * @param  string $objectType   story|task|bug
 * @access public
 * @return array
 */
public function getYearObjectStat($accounts, $year, $objectType)
{
    $table = '';
    if($objectType == 'story') $table = TABLE_STORY;
    if($objectType == 'task')  $table = TABLE_TASK;
    if($objectType == 'bug')   $table = TABLE_BUG;
    if(empty($table)) return array();

    $months = $this->getYearMonths($year);
    $stmt   = $this->dao->select('t1.*, t2.status')->from(TABLE_ACTION)->alias('t1')
        ->leftJoin($table)->alias('t2')->on('t1.objectID=t2.id')
        ->where('t1.objectType')->eq($objectType)
        ->andWhere('t2.deleted')->eq(0)
        ->andWhere('LEFT(t1.date, 4)')->eq($year)
        ->andWhere('t1.action')->in(array_keys($this->config->report->annualData['month'][$objectType]))
        ->beginIF($accounts)->andWhere('t1.actor')->in($accounts)->fi()
        ->query();

    /* Build object action stat and get status group. */
    $statuses   = array();
    $actionStat = array();
    while($action = $stmt->fetch())
    {
        $statuses[$action->objectID] = $action->status;

        $lowerAction = strtolower($action->action);
        if(!isset($actionStat[$lowerAction]))
        {
            foreach($months as $month) $actionStat[$lowerAction][$month] = 0;
        }

        $month = substr($action->date, 0, 7);
        $actionStat[$lowerAction][$month] += 1;
    }

    /* Build status stat. */
    $statusStat = array();
    foreach($statuses as $storyID => $status)
    {
        if(!isset($statusStat[$status])) $statusStat[$status] = 0;
        $statusStat[$status] += 1;
    }

    return array('statusStat' => $statusStat, 'actionStat' => $actionStat);
}

/**
 * Get year case stat, include result and action stat.
 * 
 * @param  array  $accounts 
 * @param  string $year 
 * @access public
 * @return array
 */
public function getYearCaseStat($accounts, $year)
{
    $months = $this->getYearMonths($year);
    $stmt   = $this->dao->select('t1.*')->from(TABLE_ACTION)->alias('t1')
        ->leftJoin(TABLE_CASE)->alias('t2')->on('t1.objectID=t2.id')
        ->where('t1.objectType')->eq('case')
        ->andWhere('t2.deleted')->eq(0)
        ->andWhere('t1.action')->eq('opened')
        ->andWhere('LEFT(t1.date, 4)')->eq($year)
        ->beginIF($accounts)->andWhere('t1.actor')->in($accounts)->fi()
        ->query();

    /* Build create case stat. */
    $resultStat = array();
    $actionStat = array();
    foreach($months as $month)
    {
        $actionStat['opened'][$month]    = 0;
        $actionStat['run'][$month]       = 0;
        $actionStat['createBug'][$month] = 0;
    }

    while($action = $stmt->fetch())
    {
        $month = substr($action->date, 0, 7);
        $actionStat['opened'][$month] += 1;
    }

    /* Build testcase result stat and run case stat. */
    $stmt = $this->dao->select('t1.*')->from(TABLE_TESTRESULT)->alias('t1')
        ->leftJoin(TABLE_CASE)->alias('t2')->on('t1.case=t2.id')
        ->where('LEFT(t1.date, 4)')->eq($year)
        ->andWhere('t2.deleted')->eq(0)
        ->beginIF($accounts)->andWhere('t1.lastRunner')->in($accounts)->fi()
        ->query();
    while($testResult = $stmt->fetch())
    {
        if(!isset($resultStat[$testResult->caseResult])) $resultStat[$testResult->caseResult] = 0;
        $resultStat[$testResult->caseResult] += 1;

        $month = substr($testResult->date, 0, 7);
        $actionStat['run'][$month] += 1;
    }

    /* Build testcase create bug stat. */
    $stmt = $this->dao->select('t1.*')->from(TABLE_ACTION)->alias('t1')
        ->leftJoin(TABLE_BUG)->alias('t2')->on('t1.objectID=t2.id')
        ->where('t1.objectType')->eq('bug')
        ->andWhere('t2.deleted')->eq(0)
        ->andWhere('LEFT(t1.date, 4)')->eq($year)
        ->andWhere('t1.action')->eq('opened')
        ->andWhere('t2.case')->ne('0')
        ->beginIF($accounts)->andWhere('t1.actor')->in($accounts)->fi()
        ->query();
    while($action = $stmt->fetch())
    {
        $month = substr($action->date, 0, 7);
        $actionStat['createBug'][$month] += 1;
    }

    return array('resultStat' => $resultStat, 'actionStat' => $actionStat);
}

/**
 * Get year months.
 * 
 * @param  string $year 
 * @access public
 * @return array
 */
public function getYearMonths($year)
{
    $months = array();
    for($i = 1; $i <= 12; $i ++) $months[] = $year . '-' . sprintf('%02d', $i);

    return $months;
}

/**
 * Get status vverview.
 * 
 * @param  string $objectType 
 * @param  array  $statusStat 
 * @access public
 * @return string
 */
public function getStatusOverview($objectType, $statusStat)
{
    $allCount    = 0;
    $undoneCount = 0;
    foreach($statusStat as $status => $count)
    {
        $allCount += $count;
        if($objectType == 'story' and $status != 'closed') $undoneCount += $count;
        if($objectType == 'task' and $status != 'done' and $status != 'closed' and $status != 'cancel') $undoneCount += $count;
        if($objectType == 'bug' and $status == 'active') $undoneCount += $count;
    }

    $overview = '';
    if($objectType == 'story') $overview .= $this->lang->report->annualData->allStory;
    if($objectType == 'task')  $overview .= $this->lang->report->annualData->allTask;
    if($objectType == 'bug')   $overview .= $this->lang->report->annualData->allBug;
    $overview .= ' &nbsp; ' . $allCount;
    $overview .= '<br />';
    $overview .= $objectType == 'bug' ? $this->lang->report->annualData->unresolve : $this->lang->report->annualData->undone;
    $overview .= ' &nbsp; ' . $undoneCount;

    return $overview;
}
