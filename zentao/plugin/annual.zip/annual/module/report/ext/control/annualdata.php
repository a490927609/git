<?php
class report extends control
{
    /**
     * Show annual data
     *
     * @param  string $year 
     * @param  string $dept 
     * @param  string $userID 
     * @access public
     * @return void
     */
    public function annualData($year = '', $dept = '', $userID = '')
	{
		$this->app->loadLang('story');
		$this->app->loadLang('task');
		$this->app->loadLang('bug');
		$this->app->loadLang('testcase');

        $firstAction = $this->dao->select('*')->from(TABLE_ACTION)->orderBy('id')->limit(1)->fetch();
        $currentYear = date('Y');
        $firstYear   = empty($firstAction) ? $currentYear : substr($firstAction->date, 0, 4);

        /* Get years for use zentao. */
        $years = array();
        for($thisYear = $firstYear; $thisYear <= $currentYear; $thisYear ++) $years[$thisYear] = $thisYear;

        /* Init year when year is empty. */
        if(empty($year))
        {
            $year  = date('Y');
            $month = date('n');
            if($month <= $this->config->report->annualData['minMonth'])
            {
                $year -= 1;
                if(!isset($years[$year])) $year += 1;
            }
        }

        /* Get users and depts. */
        $users     = $this->loadModel('user')->getPairs('noletter|useid|noclosed');
        $users[''] = $this->lang->report->annualData->allUser;

        $depts = $this->loadModel('dept')->getOptionMenu();
        $depts = array('' => $this->lang->report->annualData->allDept) + $depts;
        if(empty($userID)) unset($depts[0]);

        $accounts = array();
        if($dept)
        {
            $accounts = $this->loadModel('dept')->getDeptUserPairs($dept);
        }
        if($userID)
        {
            $user = $this->loadModel('user')->getById($userID, 'id');
			$dept = $user->dept;
            $accounts = array($user->account => ($user->realname ? $user->realname : $user->account));
        }
        if($accounts) $accounts = array_keys($accounts);

        if($dept)
        {
            $users = $this->loadModel('dept')->getDeptUserPairs($dept, 'useid');
            $users = array('' => $this->lang->report->annualData->allUser) + $users;
        }

        /* Get annual data. */
        $data = array();
        if(!$userID)
        {
            $data['users'] = $dept ? count($accounts) :  (count($users) - 1);
        }
        else
        {
            $data['logins'] = $this->report->getUserYearLogins($accounts, $year);
        }
        $data['actions']       = $this->report->getUserYearActions($accounts, $year);
        $data['todos']         = $this->report->getUserYearTodos($accounts, $year);
        $data['contributions'] = $this->report->getUserYearContributions($accounts, $year);
        $data['projectStat']   = $this->report->getUserYearProjects($accounts, $year);
        $data['productStat']   = $this->report->getUserYearProducts($accounts, $year);
        $data['storyStat']     = $this->report->getYearObjectStat($accounts, $year, 'story');
        $data['taskStat']      = $this->report->getYearObjectStat($accounts, $year, 'task');
        $data['bugStat']       = $this->report->getYearObjectStat($accounts, $year, 'bug');
        $data['caseStat']      = $this->report->getYearCaseStat($accounts, $year);

        $yearEfforts = $this->report->getUserYearEfforts($accounts, $year);
        $data['consumed'] = $yearEfforts->consumed;

        if(empty($dept) and empty($userID)) $data['statusStat'] = $this->report->getAllTimeStatusStat();

        $this->view->title  = sprintf($this->lang->report->annualData->title, ($userID ? $users[$userID] : ($dept ? substr($depts[$dept], strrpos($depts[$dept], '/') + 1) : $depts[''])), $year);
        $this->view->data   = $data;
        $this->view->year   = $year;
        $this->view->users  = $users;
        $this->view->depts  = $depts;
        $this->view->years  = $years;
        $this->view->dept   = $dept;
        $this->view->userID = $userID;
        $this->view->months = $this->report->getYearMonths($year);
        die($this->display());
    }
}
